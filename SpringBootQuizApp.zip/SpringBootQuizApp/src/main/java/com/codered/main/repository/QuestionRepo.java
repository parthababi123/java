package com.codered.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.codered.main.model.Question;

@Repository
public interface QuestionRepo extends JpaRepository<Question, Integer> 
{
	/*
	@Query("select a.ques_id\n"
			+ "from questions a, que_quiz_map b\n"
			+ "where b.quiz_id =:qid and a.ques_id = b.que_id")
	public List<Question> getQuestionByQuizId(@Param("qid") int qid);
	*/
}