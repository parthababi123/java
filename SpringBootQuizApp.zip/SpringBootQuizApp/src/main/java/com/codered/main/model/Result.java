package com.codered.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "results")
public class Result {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int result_id;
	private int quiz_id;
	private int login_id;
	private int totalCorrect = 0;
	
	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Result(int result_id, int quiz_id, int login_id, int totalCorrect) {
		super();
		this.result_id = result_id;
		this.quiz_id = quiz_id;
		this.login_id = login_id;
		this.totalCorrect = totalCorrect;
	}

	public int getResult_id() {
		return result_id;
	}

	public void setResult_id(int result_id) {
		this.result_id = result_id;
	}

	public int getQuiz_id() {
		return quiz_id;
	}

	public void setQuiz_id(int quiz_id) {
		this.quiz_id = quiz_id;
	}

	public int getLogin_id() {
		return login_id;
	}

	public void setLogin_id(int login_id) {
		this.login_id = login_id;
	}

	public int getTotalCorrect() {
		return totalCorrect;
	}

	public void setTotalCorrect(int totalCorrect) {
		this.totalCorrect = totalCorrect;
	}

	@Override
	public String toString() {
		return "Result [result_id=" + result_id + ", quiz_id=" + quiz_id + ", login_id=" + login_id + ", totalCorrect="
				+ totalCorrect + "]";
	}
	
	
}
