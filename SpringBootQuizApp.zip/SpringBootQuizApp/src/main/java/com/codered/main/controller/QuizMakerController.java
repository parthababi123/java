package com.codered.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.codered.main.model.Que_Quiz_Map;
import com.codered.main.model.Question;
import com.codered.main.model.Quiz;
import com.codered.main.model.Result;
import com.codered.main.repository.Que_Quiz_MapRepo;
import com.codered.main.repository.QuestionRepo;
import com.codered.main.repository.QuizRepository;


@Controller
public class QuizMakerController 
{
	private int qid=0;
	@Autowired
	private QuestionRepo questionRepo;
	@Autowired
	private QuizRepository quizRepository;
	@Autowired
	private Que_Quiz_MapRepo que_Quiz_MapRepo;
	
	@GetMapping("/createQuiz") 
	public String createQuiz() 
	{ return "adminPortal"; }
	
	@RequestMapping("/viewQuiz")
	public String viewQuiz(Model m) 
	{
		List<Quiz> qList = quizRepository.findAll();
		m.addAttribute("qList", qList);
		return "viewQuizzes";
	}
	
	//to add quiz in db
	@RequestMapping( value = "/addQue", method = RequestMethod.POST)
	public String callAddQues(@ModelAttribute Quiz quiz, Model m) 
	{
		List<Quiz> qlist = this.quizRepository.findAll();
		for(Quiz i:qlist)
		{
			if( i.getQuiz_name().equals(quiz.getQuiz_name()))
			{
				if(i.getQuiz_key().equals(quiz.getQuiz_key())) 
				{
					this.qid=i.getQuiz_id();
					return "addQuestion";
				}
				else
				{
					return "adminPortal";
				}
			}
		}
		quizRepository.save(quiz);
		System.out.println(quiz.getQuiz_id());
		this.qid = quiz.getQuiz_id();
		m.addAttribute(quiz);
		return "addQuestion";
	}
	
	//to save Questions data and map que_id
	@RequestMapping(value = "/successAddQue",method = RequestMethod.POST)
	public String new_Que(@ModelAttribute Question question )
	{
		System.out.println(question);
		this.questionRepo.save(question);
	
		//to map
		Que_Quiz_Map map = new Que_Quiz_Map();
		map.setQue_id(question.getQuesId());
		map.setQuiz_id(this.qid); //to add quiz_id here*
		this.que_Quiz_MapRepo.save(map);
		
		return "addQuestion";
		
	}
	
	@GetMapping("/viewResults") 
	public String viewResults() 
	{ return "viewResults"; }
	
	
}