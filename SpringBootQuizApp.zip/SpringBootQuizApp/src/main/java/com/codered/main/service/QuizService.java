package com.codered.main.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.codered.main.model.Que_Quiz_Map;
import com.codered.main.model.Question;
import com.codered.main.model.QuestionForm;
import com.codered.main.model.Result;
import com.codered.main.repository.Que_Quiz_MapRepo;
import com.codered.main.repository.QuestionRepo;
import com.codered.main.repository.ResultRepo;

@Service
public class QuizService 
{
	
	@Autowired
	Question question;
	@Autowired
	QuestionForm qForm;
	@Autowired
	QuestionRepo qRepo;
	@Autowired
	Result result;
	@Autowired
	ResultRepo rRepo;
	@Autowired
	Que_Quiz_MapRepo que_Quiz_MapRepo;
	
	//get all questions according to quiz_id
	public QuestionForm getQuestions(int quizId) 
	{

		List<Question> allQues = qRepo.findAll();
		
		System.out.println(allQues);
		
		List<Que_Quiz_Map> maplist = que_Quiz_MapRepo.findAll();
		List<Question> list = new ArrayList<Question>();
		for(Question i : allQues)
		{
			for(Que_Quiz_Map k : maplist)
			{
				if(i.getQuesId()==k.getQue_id() && k.getQuiz_id()==quizId)
				{
					list.add(i);
				}
			}
		}
		
		List<Question> qList = new ArrayList<Question>();
		
		Random random = new Random();
		
		//if no of questions are less than 5
		if(list.size()>=5)
		{
			for(int i=0; i<list.size(); i++) 
			{
				int rand = random.nextInt(list.size());
				qList.add(list.get(rand));
				list.remove(rand);
			}
		}
		//if no of questions are greater than 5
		else
		{
			for(int i=0; i<list.size(); i++) 
			{
				qList.add(list.get(i));
			}

		}
		qForm.setQuestions(qList);
		
		return qForm;
	}
	
	//to get result on result.html -->working
	public int getResult(QuestionForm qForm) {
		int correct = 0;
		
		for(Question q: qForm.getQuestions())
			if(q.getAns() == q.getChose())
				correct++;
		
		return correct;
	}
	
	//to save score
	public void saveScore(Result result) 
	{
		Result saveResult = new Result();
		//saveResult.setUsername(result.getUsername());
		saveResult.setQuiz_id(result.getQuiz_id());
		saveResult.setTotalCorrect(result.getTotalCorrect());
		rRepo.save(saveResult);
	}
	
	//to sort score
	public List<Result> getTopScore() {
		List<Result> sList = rRepo.findAll(Sort.by(Sort.Direction.DESC, "totalCorrect"));
		
		return sList;
	}
}
