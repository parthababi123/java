package com.codered.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.codered.main.model.Que_Quiz_Map;
import com.codered.main.model.Quiz;

@Repository
public interface Que_Quiz_MapRepo extends JpaRepository<Que_Quiz_Map, Integer> 
{
	public List<Que_Quiz_Map> findAll();
}
