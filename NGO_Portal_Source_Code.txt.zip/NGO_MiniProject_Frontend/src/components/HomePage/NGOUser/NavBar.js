import { React, useState } from 'react'

import { NavLink } from 'react-router-dom'

import EventPopup from './EventPopup'

import AddJobPopup from './AddJobPopup'
import './NgoUser.css'
import AddFundraiserPopup from './AddFundraiserPopup'
import Logout from '../../../services/Logout'

import ProfileNGO from './ProfileNGO'



const NavBar = () => {
	const [openPopup, setOpenPopup] = useState(false)
	const [openPopupJob, setOpenPopupJob] = useState(false)
	const [openPopupFund, setOpenPopupFund] = useState(false)
	const [openPopupProfile, setopenPopupProfile] = useState(false)
	return (
		<div>
			<nav class='navbar navbar-expand-lg navbar-dark bg-dark sticky-top'>
				<NavLink className='navbar-brand' to='#'>
					Broadway to NGO
				</NavLink>
				<button
					className='navbar-toggler'
					type='button'
					data-toggle='collapse'
					data-target='#navbarSupportedContent'
					aria-controls='navbarSupportedContent'
					aria-expanded='false'
					aria-label='Toggle navigation'>
					<span className='navbar-toggler-icon'></span>
				</button>

				<div className='collapse navbar-collapse' id='navbarSupportedContent'>
					<ul className='navbar-nav mr-auto'>
						<li className='nav-item active'>
							<NavLink className='nav-link' to='/home'>
								Home <span className='sr-only'>(current)</span>
							</NavLink>
						</li>
						<li className='nav-item active'>
							<NavLink
								class='nav-link'
								to='#'
								tabindex='-1'
								onClick={() => setopenPopupProfile(true)}
								ria-disabled='true'>
								Profile
							</NavLink>
						</li>
						<li className='nav-item active'>
							<NavLink
								class='nav-link'
								to='#'
								tabindex='-1'
								onClick={() => setOpenPopup(true)}
								aria-disabled='true'>
								Update Event
							</NavLink>
						</li>
						<li className='nav-item active'>
							<NavLink
								class='nav-link'
								to='#'
								tabindex='-1'
								onClick={() => setOpenPopupJob(true)}
								aria-disabled='true'>
								Add Job
							</NavLink>
						</li>
						<li className='nav-item active'>
							<NavLink
								class='nav-link'
								to='#'
								tabindex='-1'
								onClick={() => setOpenPopupFund(true)}
								aria-disabled='true'>
								Add Fundraiser
							</NavLink>
						</li>
					</ul>

					<div class='form-inline my-2 my-lg-0'>
						<a href='/login'>
							<button
								class='btn search-button my-2 my-sm-0'
								type='submit'
								onClick={() => Logout.logout()}>
								Logout
							</button>
						</a>
					</div>
				</div>
			</nav>

			<EventPopup
				title='Event From'
				openPopup={openPopup}
				setOpenPopup={setOpenPopup}></EventPopup>

			<AddJobPopup
				title='Add Job Details'
				openPopupJob={openPopupJob}
				setOpenPopupJob={setOpenPopupJob}></AddJobPopup>

			<AddFundraiserPopup
				title='Add Fundraiser'
				openPopupFund={openPopupFund}
				setOpenPopupFund={setOpenPopupFund}></AddFundraiserPopup>

			<ProfileNGO
				title='Profile'
				openPopupProfile={openPopupProfile}
				setopenPopupProfile={setopenPopupProfile}
			></ProfileNGO>

		</div>
	)
}

export default NavBar
