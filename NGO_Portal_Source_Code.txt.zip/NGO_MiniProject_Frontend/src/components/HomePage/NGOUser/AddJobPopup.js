import { React, useState } from 'react'
import {
	Dialog,
	DialogTitle,
	DialogContent,
	makeStyles,
} from '@material-ui/core'
import NGOservice from '../../../services/NGOservice'
import Toast from '../../Toast/Toasts'
import { ToastContainer } from 'react-toastify'

const AddJobPopup = (props) => {
	const [title, setTitle] = useState('')
	const [position, setPosition] = useState('')
	const [primarySkill, setPrimarySkill] = useState('')
	const [location, setLocation] = useState('')
	const [ctc, setCTC] = useState('')

	const jobinfo = async (e) => {
		e.preventDefault()
		const jobForm = {
			jobTitle: title,
			jobPosition: position,
			jobLocation: location,
			jobPrimarySkill: primarySkill,
			jobCTC: ctc,
			ngoEmail: localStorage.getItem('ngoEmail'),
		}
		try {
			const token = localStorage.getItem('token')
			NGOservice.setToken(token)
			const res = await NGOservice.addJob(jobForm)
			// console.log(res)
			setCTC('')
			setLocation('')
			setPosition('')
			setPrimarySkill('')
			setTitle('')
			Toast.toastsuccess(res.message)
		} catch (error) {
			Toast.toasterror(error.response.data.message)
		}
	}

	const useStyles = makeStyles((theme) => ({
		dialogWrapper: {
			padding: theme.spacing(2),
			position: 'absolute',
			top: theme.spacing(5),
		},
		dialogTitle: {
			paddingRight: '0px',
		},
	}))
	const { Popuptitle, childern, openPopupJob, setOpenPopupJob } = props
	const classes = useStyles()

	return (
		<Dialog
			open={openPopupJob}
			maxWidth='md'
			classes={{ paper: classes.dialogWrapper }}>
			<DialogTitle dividers className={classes.dialogTitle}>
				<div style={{ display: 'flex' }}>
					<div style={{ flexGrow: 1 }}>
						<b>Add Job Details</b>
					</div>
					<button
						text='X'
						className='btn btn-danger'
						onClick={() => setOpenPopupJob(false)}>
						X
					</button>
				</div>
			</DialogTitle>
			<DialogContent>
				<div>
					<ToastContainer></ToastContainer>
					<form method='post' onSubmit={(e) => jobinfo(e)}>
						<div className='form-row'>
							<div className='form-group col-md-6'>
								<label>NGO Name:</label>
								<label for='ngo name'>{localStorage.getItem('ngoName')}</label>
							</div>
							<div className='form-group col-md-6'>
								<label for='id'>NGO Id: </label>
								<label for='id'>{localStorage.getItem('ngoRegID')}</label>
							</div>
							<div className='form-group col-md-6'>
								<label>Job Title: </label>
								<input
									type='text'
									className='form-control'
									id='title'
									placeholder='Job Title'
									value={title}
									onChange={(e) => setTitle(e.target.value)}
								/>
							</div>
							<div className='form-group col-md-6'>
								<label>Job Position: </label>
								<input
									type='text'
									className='form-control'
									id='position'
									placeholder='Job Position'
									value={position}
									onChange={(e) => setPosition(e.target.value)}
								/>
							</div>
						</div>
						<div className='form-row'>
							<div className='form-group col-md-6'>
								<label for='location'>Job Location: </label>
								<input
									id='location'
									name='location'
									placeholder='Job Location'
									class='form-control'
									required='required'
									type='text'
									value={location}
									onChange={(e) => setLocation(e.target.value)}
								/>
							</div>
							<div className='form-group col-md-6'>
								<label for='primary skill'>Primary Skill </label>
								<input
									id='primary skill'
									name='primary skill'
									placeholder='Primary Skill'
									className='form-control'
									required='required'
									type='text'
									value={primarySkill}
									onChange={(e) => setPrimarySkill(e.target.value)}
								/>
							</div>
							<div className='form-group col-md-6'>
								<label for='primary skill'>CTC offered: </label>
								<input
									id='primary skill'
									name='primary skill'
									placeholder='CTC *'
									className='form-control'
									required='required'
									type='text'
									value={ctc}
									onChange={(e) => setCTC(e.target.value)}
								/>
							</div>
						</div>

						<div className='form-row justify-content-center'>
							<button
								type='submit'
								style={{
									background: '#002db3',
									color: 'white',
									borderRadius: '130px',
									width: '100%',
									height: '40px',
									fontWeight: 'bold',
									letterSpacing: '1px',
								}}>
								Submit
							</button>
						</div>
					</form>
				</div>
			</DialogContent>
		</Dialog>
	)
}

export default AddJobPopup
