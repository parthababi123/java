import { React, useState } from 'react'
import { ToastContainer } from 'react-toastify'
import Ngoservice from '../../../services/NGOservice'
import {
	Dialog,
	DialogTitle,
	DialogContent,
	makeStyles,
} from '@material-ui/core'
import Toast from '../../Toast/Toasts'
const AddFundraiserPopup = (props) => {
	const [frtitle, setFrtitle] = useState('')
	const [frdesc, setFrdesc] = useState('')

	const addFundRaiser = async (e) => {
		e.preventDefault()
		const fundInfo = {
			frTitle: frtitle,
			frDescription: frdesc,
			ngoEmail: localStorage.getItem('ngoEmail'),
		}
		try {
			const token = localStorage.getItem('token')
			Ngoservice.setToken(token)
			const res = await Ngoservice.addFundRaiser(fundInfo)
			setFrtitle('')
			setFrdesc('')
			Toast.toastsuccess(res.message)
		} catch (error) {
			Toast.toasterror(error.response.data.message)
		}
	}

	const useStyles = makeStyles((theme) => ({
		dialogWrapper: {
			padding: theme.spacing(2),
			position: 'absolute',
			top: theme.spacing(5),
		},
		dialogTitle: {
			paddingRight: '0px',
		},
	}))

	const { Popuptitle, childern, openPopupFund, setOpenPopupFund } = props
	const classes = useStyles()

	return (
		<Dialog
			open={openPopupFund}
			maxWidth='md'
			classes={{ paper: classes.dialogWrapper }}>
			<DialogTitle dividers className={classes.dialogTitle}>
				<div style={{ display: 'flex' }}>
					<div style={{ flexGrow: 1 }}>
						<b>Add Fund Details</b>
					</div>
					<button
					
						text='X'
						className='btn btn-danger'
						onClick={() => setOpenPopupFund(false)}>
						X
					</button>
				</div>
			</DialogTitle>
			<DialogContent>
				<div>
					<ToastContainer></ToastContainer>
					<form method='post' onSubmit={(e) => addFundRaiser(e)}>
						<div class='form-row'>
							<div class='form-group col-md-6'>
								<label>NGO Name: </label>
								<label for='ngo name'>{localStorage.getItem('ngoName')}</label>
							</div>
							<div class='form-group col-md-6'>
								<label for='id'>NGO Id: </label>
								<label for='id'>{localStorage.getItem('ngoRegID')}</label>
							</div>
							<div class='form-group col-md-12'>
								<label>Title: </label>
								<input
									type='text'
									class='form-control'
									id='Event'
									value={frtitle}
									onChange={(e) => setFrtitle(e.target.value)}
									placeholder='Title *'
									required
								/>
							</div>
						</div>
						<div class='form-row'>
							<div class='form-group col-md-12'>
								<label>Description: </label>
								<input
									placeholder='Description * '
									className='form-control'
									required='required'
									value={frdesc}
									onChange={(e) => setFrdesc(e.target.value)}
									type='text'
									required
								/>
							</div>
						</div>

						<div class='form-row justify-content-center'>
							<button
								type='submit'
								style={{
										background: '#002db3',
										color: 'white',
										borderRadius: '130px',
										width: '100%',
										height: '40px',
										fontWeight: 'bold',
										letterSpacing: '1px',
								}}>
								Submit
							</button>
						</div>
					</form>
				</div>
			</DialogContent>
		</Dialog>
	)
}

export default AddFundraiserPopup
