import React, { useState } from 'react'
import {
	Dialog,
	DialogTitle,
	DialogContent,
	makeStyles,
} from '@material-ui/core'
// import EventForm from './EventForm'
import NGOservice from '../../../services/NGOservice'
import Toast from '../../Toast/Toasts'
import { ToastContainer } from 'react-toastify'
const Popup = (props) => {
	const [eventname, setEventName] = useState('')
	const [eventdate, setEventDate] = useState('')
	const [eventdesc, setEventDesc] = useState('')
	const [eventcity, setEventCity] = useState('')
	const [eventstate, setEventState] = useState('')

	const addEvent = async (e) => {
		e.preventDefault()
		const eventForm = {
			eventName: eventname,
			eventDescription: eventdesc,
			eventDate: eventdate,
			eventLocCity: eventcity,
			eventLocState: eventstate,
			ngoEmail: localStorage.getItem('ngoEmail'),
		}
		try {
			const token = localStorage.getItem('token')
			NGOservice.setToken(token)
			const res = await NGOservice.addEvent(eventForm)

			setEventCity('')
			setEventDate('')
			setEventDesc('')
			setEventName('')
			setEventState('')
			// console.log(res)
			Toast.toastsuccess(res.message)
		} catch (error) {
			Toast.toasterror(error.response.data.message)
		}
	}

	const useStyles = makeStyles((theme) => ({
		dialogWrapper: {
			padding: theme.spacing(2),
			position: 'absolute',
			top: theme.spacing(5),
		},
		dialogTitle: {
			paddingRight: '0px',
		},
	}))
	const { title, childern, openPopup, setOpenPopup } = props
	const classes = useStyles()

	return (
		<Dialog
			open={openPopup}
			maxWidth='md'
			classes={{ paper: classes.dialogWrapper }}>
			<DialogTitle dividers className={classes.dialogTitle}>
				<div style={{ display: 'flex' }}>
					<div style={{ flexGrow: 1 }}>{title}</div>
					<button
						text='X'
						className='btn btn-danger'
						onClick={() => setOpenPopup(false)}>
						X
					</button>
				</div>
			</DialogTitle>
			<DialogContent>
				<div>
					<ToastContainer></ToastContainer>
					<form method='post' onSubmit={(e) => addEvent(e)}>
						<div class='form-row'>
							<div class='form-group col-md-6'>
								<label>NGO Name: </label>
								<label for='ngo name'>{localStorage.getItem('ngoName')}</label>
							</div>
							<div class='form-group col-md-6'>
								<label for='id'>NGO Id: </label>
								<label for='id'>{localStorage.getItem('ngoRegID')}</label>
							</div>
							<div class='form-group col-md-6'>
								<label>Event Name: </label>
								<input
									type='text'
									class='form-control'
									id='Event'
									required
									value={eventname}
									onChange={(e) => setEventName(e.target.value)}
									placeholder='Event'
								/>
							</div>
							<div class='form-group col-md-6'>
								<label for='date'>Event Date: </label>
								<input
									id='Date'
									name='date'
									placeholder='Event Date'
									class='form-control'
									required='required'
									type='text'
									value={eventdate}
									onChange={(e) => setEventDate(e.target.value)}
									onFocus={(e) => (e.target.type = 'date')}
									onBlur={(e) => (e.target.type = 'text')}
								/>
							</div>
						</div>
						<div class='form-row'>
							<div class='form-group col-md-12'>
								<label>Provide a description of the event: </label>
								<input
									type='text'
									class='form-control'
									placeholder='Description of the event..'
									required
									value={eventdesc}
									onChange={(e) => setEventDesc(e.target.value)}
								/>
							</div>
						</div>
						<div class='form-row'>
							<div class='form-group col-md-6'>
								<label for='city'>Event City: </label>
								<input
									id='city'
									name='city'
									placeholder='Event City'
									class='form-control'
									required='required'
									value={eventcity}
									onChange={(e) => setEventCity(e.target.value)}
									type='text'
								/>
							</div>
							<div class='form-group col-md-6'>
								<label for='state'>Event State: </label>
								<input
									id='state'
									name='state'
									placeholder='Event State'
									class='form-control'
									required='required'
									value={eventstate}
									onChange={(e) => setEventState(e.target.value)}
									type='text'
								/>
							</div>
						</div>
						<div class='form-row justify-content-center'>
							<button
								type='submit'
								style={{
									background: '#002db3',
										color: 'white',
										borderRadius: '130px',
										width: '100%',
										height: '40px',
										fontWeight: 'bold',
										letterSpacing: '1px',
								}}>
								Submit
							</button>
						</div>
					</form>
				</div>
			</DialogContent>
		</Dialog>
	)
}

export default Popup
