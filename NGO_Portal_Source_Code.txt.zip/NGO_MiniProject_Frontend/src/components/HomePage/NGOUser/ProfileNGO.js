import React from 'react'
import {
	Dialog,
	DialogTitle,
	DialogContent,
	makeStyles,
} from '@material-ui/core'
const ProfileNGO = (props) => {
	const useStyles = makeStyles((theme) => ({
		dialogWrapper: {
			padding: theme.spacing(2),
			position: 'absolute',
			top: theme.spacing(5),
		},
		dialogTitle: {
			paddingRight: '0px',
		},
	}))
	const { title, childern, openPopupProfile, setOpenPopupProfile } = props
	const classes = useStyles()

	return (
		<Dialog
			open={openPopupProfile}
			maxWidth='md'
			classes={{ paper: classes.dialogWrapper }}>
			<DialogTitle dividers className={classes.dialogTitle}>
				<div style={{ display: 'flex' }}>
					<div style={{ flexGrow: 1 }}>
						<b>Profile</b>
					</div>
					<button
						text='X'
						className='btn btn-danger'
						onClick={() => setOpenPopupProfile(false)}>
						X
					</button>
				</div>
			</DialogTitle>
			<DialogContent style={{ display: 'grid' }}>
				<h4 style={{ textAlign: 'left' }}>
					<label>Name :</label> {localStorage.getItem('ngoName')}
				</h4>
				<h4 style={{ textAlign: 'left' }}>
					<label>Email :</label> {localStorage.getItem('ngoEmail')}
				</h4>
				<h4 style={{ textAlign: 'left' }}>
					<label>Registration ID :</label>{' '}
					<span>{localStorage.getItem('ngoRegID')}</span>
				</h4>
				<h4 style={{ textAlign: 'left' }}>
					<label>Contact :</label> {localStorage.getItem('ngoContact')}
				</h4>

				{/* All details about Event Job and Funds in Table */}

				<div class='container event-buttons text-center'>
					<div class='row'>
						<div class='col'>
							<button
								type='button'
								style={{
									background: 'blueviolet',
									color: 'white',
									borderRadius: '130px',
									width: '100%',
									marginTop: '5%',
									height: '40px',
								}}>
								Event
							</button>
						</div>
						<div class='col'>
							<button
								type='button'
								style={{
									background: 'blueviolet',
									color: 'white',
									borderRadius: '130px',
									width: '100%',
									marginTop: '5%',
									height: '40px',
								}}>
								Job
							</button>
						</div>
						<div class='col'>
							<button
								type='button'
								style={{
									background: 'blueviolet',
									color: 'white',
									borderRadius: '130px',
									width: '100%',
									marginTop: '5%',
									height: '40px',
								}}>
								Fundraise
							</button>
						</div>
					</div>
				</div>
				<hr />
				<div class='container text-center'>
					<table class='table'>
						<thead>
							<tr>
								<th scope='col'>Name</th>
								<th scope='col'>Date</th>
								<th scope='col'>City</th>
								<th scope='col'>State</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope='row'>A</th>
								<td>Mark</td>
								<td>Otto</td>
								<td>@mdo</td>
							</tr>
							<tr>
								<th scope='row'>B</th>
								<td>Jacob</td>
								<td>Thornton</td>
								<td>@fat</td>
							</tr>
							<tr />
						</tbody>
					</table>
				</div>

				<div class='container text-center'>
					<table class='table'>
						<thead>
							<tr>
								<th scope='col'>Title</th>
								<th scope='col'>Position</th>
								<th scope='col'>Primary Skill</th>
								<th scope='col'>Location</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope='row'>A</th>
								<td>Mark</td>
								<td>Otto</td>
								<td>@mdo</td>
							</tr>
							<tr>
								<th scope='row'>B</th>
								<td>Jacob</td>
								<td>Thornton</td>
								<td>@fat</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class='container text-center'>
					<table class='table'>
						<thead>
							<tr>
								<th scope='col'>Title</th>
								<th scope='col'>Description</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope='row'>A</th>
								<td>Mark</td>
							</tr>
							<tr>
								<th scope='row'>B</th>
								<td>Jacob</td>
							</tr>
						</tbody>
					</table>
				</div>
			</DialogContent>
		</Dialog>
	)
}

export default ProfileNGO
