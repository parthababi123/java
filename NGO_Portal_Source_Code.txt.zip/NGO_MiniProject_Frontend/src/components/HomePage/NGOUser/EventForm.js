import React from 'react'
import './NgoUser.css'


const EventForm = () => {
	return (
		<div>
			<section class='registration py-5' id='registration'>
				<div class='container'>
					<div class='row'>
						<div class='col-md-4 py-5 bg-primary text-white text-center'>
							<div class='' style='margin-top: 150px;'>
								<div class='card-body'>
									<img
										src='http://www.ansonika.com/mavia/img/registration_bg.svg'
										style='width:30%'
									/>
									<h2 class='py-3'>Registration</h2>
									<p>Please register yourself first</p>
								</div>
							</div>
						</div>
						<div class='col-md-8 py-5 border'>
							<h4 class='pb-4'>Please fill the event drive details</h4>
							<form>
								<div class='form-row'>
									<div class='form-group col-md-6'>
										<label>NGO Name: </label>
										<label for='ngo name'></label>
									</div>
									<div class='form-group col-md-6'>
										<label for='id'>NGO Id: </label>
										<label for='id'></label>
									</div>
									<div class='form-group col-md-6'>
										<label>Event Name: </label>
										<input
											type='text'
											class='form-control'
											id='Event'
											placeholder='Event'
										/>
									</div>
									<div class='form-group col-md-6'>
										<label for='date'>Event Date: </label>
										<input
											id='Date'
											name='date'
											placeholder='Event Date'
											class='form-control'
											required='required'
											type='date'
										/>
									</div>
								</div>
								<div class='form-row'>
									<div class='form-group col-md-12'>
										<label>Provide a description of the event: </label>
										<input
											type='text'
											cols='40'
											rows='5'
											class='form-control'
											placeholder='Description of the event..'
											required
										/>
									</div>
								</div>
								<div class='form-row'>
									<div class='form-group col-md-6'>
										<label for='city'>Event City: </label>
										<input
											id='city'
											name='city'
											placeholder='Event City'
											class='form-control'
											required='required'
											type='text'
										/>
									</div>
									<div class='form-group col-md-6'>
										<label for='state'>Event State: </label>
										<input
											id='state'
											name='state'
											placeholder='Event State'
											class='form-control'
											required='required'
											type='text'
										/>
									</div>
								</div>
								<div class='form-row justify-content-center'>
									<button type='button' class='btn event-submit'>
										Submit
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</section>
		</div>
	)
}

export default EventForm
