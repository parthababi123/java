import React, { useState } from 'react'
import NavBar from './NavBar'
// import Cards from './components/Cards'
// import Carousel from "./components/Carousel/Carousel"
import Footer from './Footer'
import BodyPart from './BodyPart'
import { ToastContainer } from 'react-toastify'
import EventCards from '../../Cards/EventCards'
import JobsCard from '../../Cards/JobsCard'
import FundCards from '../../Cards/FundCards'

const EndUserHomePage = () => {
	const [showEvents, setshowEvents] = useState(true)
	const [showJobs, setshowJobs] = useState(false)
	const [showFunds, setshowFunds] = useState(false)

	const redButton = {
		color: 'black',
		backgroundColor: '#33adff',
		padding: '10px',
		fontSize: '20px',
		fontWeight: 'bold',
		border: 'none',
		width: '50%',
	}

	const blackButton = {
		color: 'white',
		backgroundColor: '#002db3',
		fontFamily: 'Roboto',
		fontWeight: 'bold',
		fontSize: '20px',
		padding: '10px',
		width: '50%',
	}

	return (
		<div>
			<ToastContainer></ToastContainer>
			<div className='pageContainer'>
				<div className='content-wrap'>
					<NavBar></NavBar>
					<div class='jumbotron jumbotron-fluid'>
						<div class='overlay'></div>
						<div class='container'>
							<h1 class='display-4'>
								Welcome {localStorage.getItem('userName')}{' '}
							</h1>
							<p class='lead text-center'>
								Come forward and engage with these upcoming activities
							</p>
						</div>
					</div>

					<div class='row' style={{ marginLeft: '13%' }}>
						<div class='col'>
							<button
								type='button'
								class='btn btn-outline-secondary'
								style={showEvents ? redButton : blackButton}
								onClick={() => setshowEvents(!showEvents)}>
								{!showEvents ? 'Events' : 'Close'}
							</button>
						</div>
						<div class='col'>
							<button
								type='button'
								class='btn btn-outline-secondary'
								style={showJobs ? redButton : blackButton}
								onClick={() => setshowJobs(!showJobs)}>
								{!showJobs ? 'Jobs' : 'Close'}
							</button>
						</div>
						<div class='col'>
							<button
								type='button'
								class='btn btn-outline-secondary'
								style={showFunds ? redButton : blackButton}
								onClick={() => setshowFunds(!showFunds)}>
								{!showFunds ? 'Funds' : 'Close'}
							</button>
						</div>
					</div>
					<br />
					<hr />
					<div>
						{showEvents ? (
							<EventCards />
						) : showFunds ? (
							<FundCards />
						) : showJobs ? (
							<JobsCard />
						) : (
							<></>
						)}
					</div>

					<br></br>
					<br></br>
					<hr />
					<BodyPart />
				</div>
			</div>
			<br />
			{/* Footer */}
			<Footer></Footer>
		</div>
	)
}

export default EndUserHomePage
