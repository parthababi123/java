import React from 'react'
import './EndUser.css'
const UserInfo = () => {
	return (
		<section>
			<div class='main-topic'>
				<div class='left-text'>
					<h4 style={{ textAlign: 'left' }}>
						<label>Name :</label>{' '}
						{localStorage.getItem('userName') +
							' ' +
							localStorage.getItem('userLName')}
					</h4>
					<h4 style={{ textAlign: 'left' }}>
						<label>Email :</label> {localStorage.getItem('userEmail')}
					</h4>
					<h4 style={{ textAlign: 'left' }}>
						<label>Contact :</label> {localStorage.getItem('userContact')}
					</h4>
					<h4 style={{ textAlign: 'left' }}>
						<label>DOB :</label> {localStorage.getItem('DOB')}
					</h4>
				</div>
				<div class='right-picture'>
					<img src='https://cdn1.iconfinder.com/data/icons/technology-devices-2/100/Profile-512.png' />
				</div>
				<div class='clear'></div>
			</div>
		</section>
	)
}
export default UserInfo
