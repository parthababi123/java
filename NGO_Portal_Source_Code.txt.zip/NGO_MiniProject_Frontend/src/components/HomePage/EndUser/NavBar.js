import { React, useState } from 'react'

import { Link } from 'react-router-dom'

import Logout from '../../../services/Logout'

const NavBar = () => {
	return (
		<div>
			<nav class='navbar sticky-top navbar-expand-lg navbar-dark bg-dark'>
				<div class='navbar-brand'>Broadway to NGO</div>
				<button
					class='navbar-toggler'
					type='button'
					data-toggle='collapse'
					data-target='#navbarSupportedContent'
					aria-controls='navbarSupportedContent'
					aria-expanded='false'
					aria-label='Toggle navigation'>
					<span class='navbar-toggler-icon'></span>
				</button>

				<div class='collapse navbar-collapse' id='navbarSupportedContent'>
					<ul class='navbar-nav mr-auto'>
						<li class='nav-item active'>
							<Link to='/home' class='nav-item'>
								Home{' '}
							</Link>
						</li>

					</ul>
					<div class='form-inline my-2 my-lg-0'>
						<a href='/login'>
							<button
								class='btn search-button my-2 my-sm-0'
								type='submit'
								onClick={() => Logout.logout()}>
								Logout
							</button>
						</a>
					</div>
				</div>
			</nav>
		</div>
	)
}

export default NavBar
