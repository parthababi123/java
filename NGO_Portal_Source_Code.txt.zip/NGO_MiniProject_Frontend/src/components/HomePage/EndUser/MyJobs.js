import React, { useState, useEffect } from 'react'
import Volunteerservice from '../../../services/Volunteerservice'

const MyJobs = () => {
	const [jobs, setJobs] = useState([])
	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			Volunteerservice.setToken(token)
			const response = await Volunteerservice.volunteerJobs(
				localStorage.getItem('userEmail')
			)
			setJobs(response.myjobs)
		}
		fetchData()
	}, [])
	return (
		<div class='container text-center'>
			<table class='table'>
				<thead>
					<tr>
						<th scope='col'>Title</th>
						<th scope='col'>Position</th>
						<th scope='col'>Skill</th>
						<th scope='col'>Location</th>
						<th scope='col'>CTC</th>
					</tr>
				</thead>
				<tbody>
					{jobs ? (
						jobs.map((job) => {
							return (
								<tr>
									<th scope='row'>{job.jobTitle}</th>
									<td>{job.jobPosition}</td>
									<td>{job.jobPrimarySkill}</td>
									<td>{job.jobLocation}</td>
									<td>{job.jobCTC}</td>
								</tr>
							)
						})
					) : (
						<h3>No jobs yet</h3>
					)}
				</tbody>
			</table>
		</div>
	)
}
export default MyJobs
