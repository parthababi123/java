import React, { useState, useEffect } from 'react'
import Volunteerservice from '../../../services/Volunteerservice'
const MyFRs = () => {
	const [funds, setFunds] = useState([])
	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			Volunteerservice.setToken(token)
			const response = await Volunteerservice.volunteerFRs(
				localStorage.getItem('userEmail')
			)
			setFunds(response.myfundraisers)
		}
		fetchData()
	}, [])
	return (
		<div class='container text-center'>
			<table class='table'>
				<thead>
					<tr>
						<th scope='col'>Title</th>
						<th scope='col'>Description</th>
					</tr>
				</thead>
				<tbody>
					{funds ? (
						funds.map((fund) => {
							return (
								<tr>
									<th scope='row'>{fund.frTitle}</th>
									<td>{fund.frDescription}</td>
								</tr>
							)
						})
					) : (
						<h3>No FundRaisers yet</h3>
					)}
				</tbody>
			</table>
		</div>
	)
}
export default MyFRs
