import React from 'react'
import protect from '../../../images/protect.png'
const BodyPart = () => {
	return (
		<div>
			<div class='container' style={{ display: 'block' }}>
				<div class='row mb-5'>
					<div class='col-lg-7 mx-auto text-center'>
						<br />
						<span class='subheading'>What you need to do</span>
						<h2 class='mb-4 section-heading'>How To Protect Yourself</h2>
						<p>Stay Home! Stay Safe!</p>
					</div>
				</div>
				<div class='row'>
					<div class='col-lg-6 '>
						<div class='row mt-5 pt-5'>
							<div class='col-lg-6 do '>
								<h3>You should do</h3>
								<ul class='list-unstyled check'>
									<li>Stay at home</li>
									<li>Wear mask</li>
									<li>Use Sanitizer</li>
									<li>Disinfect your home</li>
									<li>Wash your hands</li>
									<li>Frequent self-isolation</li>
								</ul>
							</div>
							<div class='col-lg-6 dont '>
								<h3>You should avoid</h3>
								<ul class='list-unstyled cross'>
									<li>Avoid infected people</li>
									<li>Avoid animals</li>
									<li>Avoid handshaking</li>
									<li>Aviod infected surfaces</li>
									<li>Don't touch your face</li>
									<li>Avoid droplets</li>
								</ul>
							</div>
						</div>
					</div>
					<div class='col-lg-6'>
						<img src={protect} alt='ImagePic' className='img-fluid' />
					</div>
				</div>
			</div>
		</div>
	)
}

export default BodyPart
