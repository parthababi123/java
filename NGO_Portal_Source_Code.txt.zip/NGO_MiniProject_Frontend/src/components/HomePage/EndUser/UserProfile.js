import React, { useState } from 'react'
import MyJobs from './MyJobs'
import MyEvents from './MyEvents'
import MyFRs from './MyFRs'
import UserInfo from './UserInfo'
import NavBar from './NavBar'
const UserProfile = () => {
	const [showjobs, setShowjobs] = useState(false)
	const [showevents, setShowevents] = useState(false)
	const [showFRs, setShowFRs] = useState(false)
	return (
		<>
			<NavBar></NavBar>
			<UserInfo></UserInfo>
			<div class='container event-buttons text-center'>
				<div class='row'>
					<div class='col'>
						<button
							style={{
								background: 'blueviolet',
								color: 'white',
								borderRadius: '130px',
								width: '50%',
								marginTop: '5%',
								height: '40px',
							}}
							onClick={() => setShowevents(!showevents)}>
							Events Registered
						</button>
					</div>
					<div class='col'>
						<button
							type='button'
							style={{
								background: 'blueviolet',
								color: 'white',
								borderRadius: '130px',
								width: '50%',
								marginTop: '5%',
								height: '40px',
							}}
							onClick={() => setShowjobs(!showjobs)}>
							Jobs Applications
						</button>
					</div>
					<div class='col'>
						<button
							type='button'
							style={{
								background: 'blueviolet',
								color: 'white',
								borderRadius: '130px',
								width: '50%',
								marginTop: '5%',
								height: '40px',
							}}
							onClick={() => setShowFRs(!showFRs)}>
							Donations
						</button>
					</div>
				</div>
			</div>
			<div>
				{showevents ? (
					<MyEvents />
				) : showjobs ? (
					<MyJobs />
				) : showFRs ? (
					<MyFRs />
				) : (
					<></>
				)}
			</div>
		</>
	)
}

export default UserProfile
