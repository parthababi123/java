import React, { useState, useEffect } from 'react'
import Volunteerservice from '../../../services/Volunteerservice'
const MyEvents = () => {
	const [events, setEvents] = useState([])
	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			Volunteerservice.setToken(token)
			const response = await Volunteerservice.volunteerEvents(
				localStorage.getItem('userEmail')
			)
			setEvents(response.myevents)
		}
		fetchData()
	}, [])
	return (
		<div class='container text-center'>
			<table class='table'>
				<thead>
					<tr>
						<th scope='col'>Name</th>
						<th scope='col'>Description</th>
						<th scope='col'>Date</th>
						<th scope='col'>Location</th>
					</tr>
				</thead>
				<tbody>
					{events ? (
						events.map((event) => {
							const [year, month, day] = event.eventDate.split('-')
							return (
								<tr>
									<th scope='row'>{event.eventName}</th>
									<td>{event.eventDescription}</td>
									<td>{day + '-' + month + '-' + year}</td>
									<td>{event.eventLocCity + ',' + event.eventLocState}</td>
								</tr>
							)
						})
					) : (
						<h3>No events registered</h3>
					)}
				</tbody>
			</table>
		</div>
	)
}
export default MyEvents
