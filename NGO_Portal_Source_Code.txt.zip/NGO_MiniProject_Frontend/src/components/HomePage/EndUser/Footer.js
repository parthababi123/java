import React from 'react'

const Footer = () => {
	const myStyle = {
		background: '#343a40',
		padding: '80px',
		color: 'white',
	}
	return (
		<div className='footer-wrapper'>
			<div className='footer-area footer-padding' style={myStyle}>
				<div className='container'>
					<div className='row justify-content-between'>
						<div className='col-xl-3 col-lg-3 col-md-6 col-sm-8'>
							<div className='single-footer-caption mb-50'>
								<div className='single-footer-caption mb-20'>
									<div className='footer-logo mb-35'>
										{/* <a href='index.html'>
											<img src='assets/img/logo/logo2_footer.png' alt='' />
										</a> */}
									</div>
									<div className='footer-tittle'>
										<div className='footer-pera'>
											<p>COVID-19 AWARENESS</p>
											<br />
											<p>Stay Safe. Stay Home.</p>
										</div>
									</div>

									{/* <div className='footer-social'>
										<a href='https://bit.ly/sai4ull'>
											<i className='fab fa-facebook'></i>
										</a>
										<a href='#'>
											<i className='fab fa-instagram'></i>
										</a>
										<a href='#'>
											<i className='fab fa-linkedin-in'></i>
										</a>
										<a href='#'>
											<i className='fab fa-youtube'></i>
										</a>
									</div> */}
								</div>
							</div>
						</div>
						<div className='offset-xl-1 col-xl-2 col-lg-2 col-md-4 col-sm-6'>
							<div className='single-footer-caption mb-50'>
								<div className='footer-tittle'>
									<h4 style={{ color: 'white' }}>Navigation</h4>
									<ul>
										<li>Home</li>
										<li>About</li>
										<li>Services</li>
										<li>Blog</li>
										<li>Contact</li>
									</ul>
								</div>
							</div>
						</div>
						<div className='col-xl-2 col-lg-2 col-md-4 col-sm-6'>
							<div className='single-footer-caption mb-50'>
								<div className='footer-tittle'>
									<h4 style={{ color: 'white' }}>Services</h4>
									<ul>
										<li>Pet Care</li>
										<li>Pet Treatment</li>
										<li>Pet Trainingl</li>
										<li>Hygienic Care</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div className='footer-bottom-area'>
				<div className='container'>
					<div className='footer-border'>
						<div className='row'>
							<div className='col-xl-12 '>
								<div className='footer-copy-right text-center'></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default Footer
