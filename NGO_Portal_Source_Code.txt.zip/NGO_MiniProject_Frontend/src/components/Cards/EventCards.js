import React, { useEffect, useState } from 'react'
import { Card, ListGroup } from 'react-bootstrap'
import Volunteerservice from '../../services/Volunteerservice'
import Toast from '../Toast/Toasts'

import ScrollMenu from 'react-horizontal-scrolling-menu'
import leftarrow from '../../images/left-arrow.png'
import rightarrow from '../../images/right-arrow.png'

const EventCards = () => {
	const [events, setEvent] = useState([])
	const [load, setLoad] = useState(false)
	const eventRegister = async (id) => {
		const eventForm = {
			id: id,
			userEmail: localStorage.getItem('userEmail'),
		}
		try {
			const token = localStorage.getItem('token')
			Volunteerservice.setToken(token)
			const res = await Volunteerservice.eventRegister(eventForm)
			Toast.toastsuccess(res.message)
		} catch (error) {
			Toast.toasterror(error.response.data.message)
		}
	}

	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			Volunteerservice.setToken(token)
			const eventsData = await Volunteerservice.getAllEvents()
			console.log(eventsData)
			setEvent(eventsData.events)
			setLoad(true)

			//console.log(events)
		}
		fetchData()
	}, [])

	const renderCard = (event, index) => {
		const edate = event.eventDate
		const [year, month, date] = edate.split('-')
		return (
			<div class='scrolling-wrapper row flex-row flex-nowrap ml-4 p-3'>
				<Card key={index} class='card-block mx-2 card' bg='light' border='dark'>
					<Card.Header>
						<Card.Title> {event.eventName}</Card.Title>
					</Card.Header>
					<Card.Body style={{ fontWeight: 'bold' }}>
						<ListGroup variant='primary'>
							<Card.Text>Date : {date + '-' + month + '-' + year}</Card.Text>
							<Card.Text>
								Location : {event.eventLocCity + ',' + event.eventLocState}
							</Card.Text>
						</ListGroup>
					</Card.Body>

					<Card.Footer>
						<button
							style={{
								background: '#002db3',
								color: 'white',
								borderRadius: '130px',
								width: '100%',
								height: '40px',
								fontWeight: 'bold',
								letterSpacing: '1px',
							}}
							onClick={() => eventRegister(event.eventID)}>
							Register
						</button>
					</Card.Footer>
				</Card>
			</div>
		)
	}
	return (
		<>
			{!events ? (
				<div className='fundrasier-message'>
					<h5>
						<strong>
							No Events available right now. Please check back later.
						</strong>
					</h5>
				</div>
			) : load && events ? (
				<ScrollMenu
					arrowLeft={
						<div style={{ fontSize: '30px' }}>
							<img
								src={leftarrow}
								alt='leftarrow'
								style={{ width: '36px' }}></img>
						</div>
					}
					arrowRight={
						<div style={{ fontSize: '30px' }}>
							<img
								src={rightarrow}
								alt='leftarrow'
								style={{ width: '36px' }}></img>
						</div>
					}
					data={events.map(renderCard)}
				/>
			) : (
				<></>
			)}
		</>
	)
}

export default EventCards
