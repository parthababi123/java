import React, { useEffect, useState } from 'react'
import { Card, ListGroup } from 'react-bootstrap'
import NGOservice from '../../services/NGOservice'

import ScrollMenu from 'react-horizontal-scrolling-menu'
import leftarrow from '../../images/left-arrow.png'
import rightarrow from '../../images/right-arrow.png'

const PostedFR = () => {
	const [funds, setFunds] = useState([])
	const [load, setLoad] = useState(false)

	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			NGOservice.setToken(token)
			const response = await NGOservice.getMyFRs(
				localStorage.getItem('ngoEmail')
			)
			setFunds(response.responses)
			setLoad(true)
			console.log(funds)
		}
		fetchData()
	}, [])

	// const cardInfo = [
	// 	{ title: 'Event Title 1', text: 'Some text for 1', buttons: 'Register' },
	// 	{ title: 'Event Title 2', text: 'Some text for 2', buttons: 'Register' },
	// ]
	const renderCard = (fund, index) => {
		return (
			<div class='scrolling-wrapper row flex-row flex-nowrap mt-4 p-3'>
				<Card
					style={{ width: '95%' }}
					key={index}
					class='card-block mx-2'
					bg='light'
					border='dark'>
					<Card.Header>
						<Card.Title style={{ fontWeight: 'bold' }}>
							{fund.frTitle}{' '}
						</Card.Title>
					</Card.Header>
					<Card.Body style={{ fontWeight: 'bold' }}>
						<ListGroup variant='primary'>
							<Card.Text>Description : {fund.frTitle} </Card.Text>
							<Card.Text>Date : {fund.frDescription}</Card.Text>
						</ListGroup>
					</Card.Body>
				</Card>
			</div>
		)
	}
	return (
		<>
			{!funds ? (
				<div className='fundrasier-message'>
					<h5>
						<strong>You have not posted any event yet.</strong>
					</h5>
				</div>
			) : load && funds ? (
				<div className='container-fluid'>
					<ScrollMenu
						arrowLeft={
							<div style={{ fontSize: '30px' }}>
								<img
									src={leftarrow}
									alt='leftarrow'
									style={{ width: '36px' }}></img>
							</div>
						}
						arrowRight={
							<div style={{ fontSize: '30px' }}>
								<img
									src={rightarrow}
									alt='leftarrow'
									style={{ width: '36px' }}></img>
							</div>
						}
						data={funds.map(renderCard)}
					/>
				</div>
			) : (
				<></>
			)}
		</>
	)
}

export default PostedFR
