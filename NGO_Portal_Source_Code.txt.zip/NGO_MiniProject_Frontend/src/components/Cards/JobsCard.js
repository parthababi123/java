import React, { useState, useEffect } from 'react'
import { Card, ListGroup } from 'react-bootstrap'
import Volunteerservice from '../../services/Volunteerservice'
import Toast from '../Toast/Toasts'

import ScrollMenu from 'react-horizontal-scrolling-menu'
import leftarrow from '../../images/left-arrow.png'
import rightarrow from '../../images/right-arrow.png'

const JobsCard = () => {
	const [jobs, setJobs] = useState([])
	const [load, setLoad] = useState(false)

	const jobApply = async (id) => {
		const jobForm = {
			id: id,
			userEmail: localStorage.getItem('userEmail'),
		}
		try {
			const token = localStorage.getItem('token')
			Volunteerservice.setToken(token)
			const res = await Volunteerservice.jobApply(jobForm)
			Toast.toastsuccess(res.message)
		} catch (error) {
			Toast.toasterror(error.response.data.message)
		}
	}
	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			Volunteerservice.setToken(token)
			const jobsData = await Volunteerservice.getAllJobs()
			console.log(jobsData)
			setJobs(jobsData.jobs)
			setLoad(true)
			//console.log(jobs)
		}
		fetchData()
	}, [])

	const renderCard = (job, index) => {
		return (
			<div class='scrolling-wrapper row flex-row flex-nowrap  ml-4 p-3'>
				<Card key={index} class=' card' bg='light' border='dark'>
					<Card.Header>
						<Card.Title>{job.jobTitle}</Card.Title>
					</Card.Header>
					<Card.Body style={{ fontWeight: 'bold' }}>
						<ListGroup variant='flush'>
							<Card.Text>Position : {job.jobPosition}</Card.Text>
							<Card.Text>Skill : {job.jobPrimarySkill}</Card.Text>
							<Card.Text>City : {job.jobLocation}</Card.Text>
							<Card.Text>CTC : {'Rs. ' + job.jobCTC}</Card.Text>
						</ListGroup>
					</Card.Body>
					<Card.Footer>
						<button
							style={{
								background: '#002db3',
								color: 'white',
								borderRadius: '130px',
								width: '100%',
								height: '40px',
								fontWeight: 'bold',
								letterSpacing: '1px',
							}}
							onClick={() => jobApply(job.jobID)}>
							Apply
						</button>
					</Card.Footer>
				</Card>
			</div>
		)
	}
	return (
		<>
			{!jobs ? (
				<>
					<div className='fundrasier-message'>
						<h5>
							<strong>
								{' '}
								No Jobs Vacancies available right now. Please check back later.
							</strong>
						</h5>
					</div>
				</>
			) : load && jobs ? (
				<ScrollMenu
					arrowLeft={
						<div style={{ fontSize: '30px' }}>
							<img
								src={leftarrow}
								alt='leftarrow'
								style={{ width: '36px' }}></img>
						</div>
					}
					arrowRight={
						<div style={{ fontSize: '30px' }}>
							<img
								src={rightarrow}
								alt='leftarrow'
								style={{ width: '36px' }}></img>
						</div>
					}
					data={jobs.map(renderCard)}
				/>
			) : (
				<></>
			)}
		</>
	)
}

export default JobsCard
