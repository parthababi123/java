import React, { useState, useEffect } from 'react'
import { Card, ListGroup } from 'react-bootstrap'
import Volunteerservice from '../../services/Volunteerservice'
import ScrollMenu from 'react-horizontal-scrolling-menu'
import Toast from '../Toast/Toasts'
import leftarrow from '../../images/left-arrow.png'
import rightarrow from '../../images/right-arrow.png'

const FundCards = () => {
	const [funds, setFunds] = useState([])
	const [load, setLoad] = useState(false)
	const [amount, setAmount] = useState(0)
	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			Volunteerservice.setToken(token)
			const fundData = await Volunteerservice.getAllFundRaisers()
			// console.log(fundData)
			setFunds(fundData.funds)
			setLoad(true)
			//console.log(jobs)
		}
		fetchData()
	}, [])
	const donateMoney = (email) => {
		const name = email.substring(0, email.indexOf('@'))

		if (amount === 0) {
			Toast.toasterror('Please enter a valid amount!')
		} else {
			let options = {
				key: 'rzp_test_tv2YMjnKno5KIx',
				amount: amount * 100, // 2000 paise = INR 20, amount in paisa
				name: 'NGO',
				description: 'Charity',

				handler: function (response) {
					alert(response.razorpay_payment_id)
				},
				prefill: {
					name: name,
					email: email,
				},

				// theme: {
				// 	color: '#F37254',
				// },
			}

			let rzp = new window.Razorpay(options)
			rzp.open()
		}
	}
	const renderCard = (fund, index) => {
		return (
			<div class='scrolling-wrapper row flex-row flex-nowrap mt-4 p-3'>
				<Card
					style={{ width: '95%' }}
					key={index}
					class='card-block mx-2'
					bg='light'
					border='dark'>
					<Card.Header>
						<Card.Title>{fund.frTitle}</Card.Title>
					</Card.Header>
					<Card.Body style={{ fontWeight: 'bold' }}>
						<ListGroup variant='flush'>
							<Card.Text>Description : {fund.frDescription}</Card.Text>
							<input
								type='text'
								placeholder='Enter amount you want to donate'
								value={amount === 0 ? '' : amount}
								onChange={(e) => setAmount(e.target.value)}
							/>
						</ListGroup>
					</Card.Body>
					<Card.Footer>
						<button
							style={{
								background: '#002db3',
								color: 'white',
								borderRadius: '130px',
								width: '100%',
								height: '40px',
								fontWeight: 'bold',
								letterSpacing: '1px',
							}}
							onClick={() => donateMoney(fund.ngoEmail)}>
							Donate
						</button>
					</Card.Footer>
				</Card>
			</div>
		)
	}
	return (
		<>
			{!funds ? (
				<div className='fundrasier-message'>
					<h5>
						<strong>
							No Fundraisers available right now. Please check back later
						</strong>
					</h5>
				</div>
			) : load && funds ? (
				<div className='container-fluid'>
					<ScrollMenu
						arrowLeft={
							<div style={{ fontSize: '30px' }}>
								<img
									src={leftarrow}
									alt='leftarrow'
									style={{ width: '36px' }}></img>
							</div>
						}
						arrowRight={
							<div style={{ fontSize: '30px' }}>
								<img
									src={rightarrow}
									alt='leftarrow'
									style={{ width: '36px' }}></img>
							</div>
						}
						data={funds.map(renderCard)}
					/>
				</div>
			) : (
				<></>
			)}
		</>
	)
}

export default FundCards
