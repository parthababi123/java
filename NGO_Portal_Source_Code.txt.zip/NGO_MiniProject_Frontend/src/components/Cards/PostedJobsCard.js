import React, { useState, useEffect } from 'react'
import { Card, Button, ListGroup } from 'react-bootstrap'
import Ngoservice from '../../services/NGOservice'
import ScrollMenu from 'react-horizontal-scrolling-menu'

const PostedJobsCard = () => {
	const [jobs, setJobs] = useState([])
	const [load, setLoad] = useState(false)

	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			Ngoservice.setToken(token)
			const response = await Ngoservice.getMyJobs(
				localStorage.getItem('ngoEmail')
			)
			console.log(response)
			setJobs(response.responses)
			setLoad(true)
		}
		fetchData()
	}, [])

	const renderCard = (job, index) => {
		return (
			<div class='scrolling-wrapper row flex-row flex-nowrap mt-4 p-3'>
				<Card
					style={{ width: '95%' }}
					key={index}
					class='card-block mx-2'
					bg='light'
					border='dark'>
					<Card.Header>
						<Card.Title style={{ fontWeight: 'bold' }}>
							{job.jobTitle}
						</Card.Title>
					</Card.Header>
					<Card.Body style={{ fontWeight: 'bold' }}>
						<ListGroup variant='primary'>
							<Card.Text>Position : {job.jobPosition} </Card.Text>
							<Card.Text>Primary skill : {job.jobPrimarySkill} </Card.Text>
							<Card.Text>Location : {job.jobLocation} </Card.Text>
							<Card.Text>CTC : {job.jobCTC}</Card.Text>
						</ListGroup>
					</Card.Body>
					<Card.Footer>No. of Applications : {job.responsesCount}</Card.Footer>
				</Card>
			</div>
		)
	}
	return (
		<>
			{!jobs ? (
				<>
					<div className='fundrasier-message'>
						<h5>
							<strong>
								You have not posted any job vacancy yet. Please post one.{' '}
							</strong>
						</h5>
					</div>
				</>
			) : load && jobs ? (
				<div className='container-fluid'>
					<ScrollMenu
						arrowLeft={<div style={{ fontSize: '30px' }}>{' < '}</div>}
						arrowRight={<div style={{ fontSize: '30px' }}>{' > '}</div>}
						data={jobs.map(renderCard)}
						alignCenter={true}
						transition='0.2'
						scrollBy={1}
						menuClass='menu-cards'
						useButtonRole={false}
						itemStyle={{ marginLeft: '1%', width: '50%', textAlign: 'center' }}
					/>
				</div>
			) : (
				<></>
			)}
		</>
	)
}

export default PostedJobsCard
