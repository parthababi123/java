import React, { useEffect, useState } from 'react'
import { Card, ListGroup } from 'react-bootstrap'
import NGOservice from '../../services/NGOservice'

import ScrollMenu from 'react-horizontal-scrolling-menu'
import leftarrow from '../../images/left-arrow.png'
import rightarrow from '../../images/right-arrow.png'

const PostedEventsCard = () => {
	const [events, setEvents] = useState([])
	const [load, setLoad] = useState(false)

	useEffect(() => {
		async function fetchData() {
			const token = localStorage.getItem('token')
			NGOservice.setToken(token)
			const response = await NGOservice.getMyEvents(
				localStorage.getItem('ngoEmail')
			)
			setEvents(response.responses)
			setLoad(true)
		}
		fetchData()
	}, [])

	// const cardInfo = [
	// 	{ title: 'Event Title 1', text: 'Some text for 1', buttons: 'Register' },
	// 	{ title: 'Event Title 2', text: 'Some text for 2', buttons: 'Register' },
	// ]
	const renderCard = (event, index) => {
		const edate = event.eventDate
		const [year, month, date] = edate.split('-')

		return (
			<div class='scrolling-wrapper row flex-row flex-nowrap mt-4 p-3'>
				<Card
					style={{ width: '95%' }}
					key={index}
					class='card-block mx-2'
					bg='light'
					border='dark'>
					<Card.Header>
						<Card.Title>{event.eventName} </Card.Title>
					</Card.Header>
					<Card.Body style={{ fontWeight: 'bold' }}>
						<ListGroup variant='primary'>
							<Card.Text>Description : {event.eventDescription} </Card.Text>
							<Card.Text>Date : {date + '-' + month + '-' + year}</Card.Text>
							<Card.Text>
								Location : {event.eventLocCity + ',' + event.eventLocState}
							</Card.Text>
						</ListGroup>
					</Card.Body>

					<Card.Footer>
						No. of Registrations : {event.responsesCount}
					</Card.Footer>
				</Card>
			</div>
		)
	}
	return (
		<>
			{!events ? (
				<div className='fundrasier-message'>
					<h5>
						<strong>You have not posted any event yet.</strong>
					</h5>
				</div>
			) : load && events ? (
				<div className='container-fluid'>
					<ScrollMenu
						arrowLeft={
							<div style={{ fontSize: '30px' }}>
								<img
									src={leftarrow}
									alt='leftarrow'
									style={{ width: '36px' }}></img>
							</div>
						}
						arrowRight={
							<div style={{ fontSize: '30px' }}>
								<img
									src={rightarrow}
									alt='leftarrow'
									style={{ width: '36px' }}></img>
							</div>
						}
						data={events.map(renderCard)}
					/>
				</div>
			) : (
				<></>
			)}
		</>
	)
}

export default PostedEventsCard
