import React, { useState, useContext } from 'react'
import 'react-toastify/dist/ReactToastify.css'
import { ToastContainer } from 'react-toastify'
import { useHistory } from 'react-router-dom'
import NGOservice from '../../services/NGOservice'
import Toast from '../Toast/Toasts'
import jwt_decode from 'jwt-decode'
import { UserContext } from '../../App'

const LoginFormNgo = () => {
	const { dispatch } = useContext(UserContext)
	const history = useHistory()
	const [email, setEmail] = useState('')
	const [password, setPassword] = useState('')

	// using axios 

	const loginNgo = async (e) => {
		e.preventDefault()
		const ngoForm = {
			email: email,
			password: password,
		}
		try {
			const res = await NGOservice.login(ngoForm)
			const token = res.token
			localStorage.setItem('token', token)
			const user = jwt_decode(token)
			localStorage.setItem('user', JSON.stringify(user))
			dispatch({ type: 'USER', payload: user })
			localStorage.setItem('ngoEmail', user.ngoEmail)
			localStorage.setItem('ngoName', user.ngoName)
			localStorage.setItem('ngoRegID', user.ngoRegID)
			localStorage.setItem('ngoContact', user.ngoContact)
			setEmail('')
			setPassword('')
			Toast.toastsuccess(res.message)
			// console.log(
			// 	localStorage.getItem('ngoEmail'),
			// 	localStorage.getItem('ngoRegID'),
			// 	localStorage.getItem('token')
			// )
			setInterval(() => history.push('/ngohome'), 3000)
		} catch (error) {
			Toast.toasterror(error.response.data.message)
		}
	}
	return (
		<div>
			<ToastContainer></ToastContainer>
			<form
				className='row register-form'
				method='post'
				onSubmit={(e) => loginNgo(e)}>
				<div className='col-md-12'>
					<h5 style={{ textAlign: 'left' }}>Email: </h5>

					<div className='form-group'>
						<input
							type='email'
							className='form-control'
							value={email}
							onChange={(e) => setEmail(e.target.value)}
							required
						/>
					</div>
					<h5 style={{ textAlign: 'left' }}>Password: </h5>

					<div className='form-group'>
						<input
							type='password'
							className='form-control'
							value={password}
							onChange={(e) => setPassword(e.target.value)}
							required
						/>
					</div>
				</div>
				<button type='submit'
					style={{
						background: '#002db3',
						color: 'white',
						borderRadius: '130px',
						width: '50%',
						height: '100%',
						fontWeight: 'bold',
						letterSpacing: '1px',
					}}
					className='btnRegister'>
					Login
				</button>
			</form>
		</div>
	)
}
export default LoginFormNgo
