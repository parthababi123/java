import React, { useState, useContext } from 'react'
import { ToastContainer } from 'react-toastify'
import Volunteerservice from '../../services/Volunteerservice'
import Toast from '../Toast/Toasts'
import { useHistory } from 'react-router-dom'
import jwt_decode from 'jwt-decode'
import { UserContext } from '../../App'

const LoginFormVolunteer = () => {

	//using axios 
	const { state, dispatch } = useContext(UserContext)
	const history = useHistory()

	const [email, setEmail] = useState('')
	const [password, setPassword] = useState('')

	const loginVolunteer = async (e) => {
		e.preventDefault()
		const volunteerForm = {
			email: email,
			password: password,
		}
		try {
			const res = await Volunteerservice.login(volunteerForm)
			const token = res.token
			localStorage.setItem('token', token)
			const user = jwt_decode(token)

			localStorage.setItem('user', JSON.stringify(user))
			dispatch({ type: 'USER', payload: user })
			localStorage.setItem('userEmail', user.userEmail)
			localStorage.setItem('userName', user.userFirstName)
			localStorage.setItem('userLName', user.userLastName)
			localStorage.setItem('userContact', user.userContact)
			localStorage.setItem('DOB', user.userDOB)
			// localStorage.setItem('user', user.ngoRegID)
			setEmail('')
			setPassword('')
			Toast.toastsuccess(res.message)
			// console.log(localStorage.getItem('user'))
			setInterval(() => history.push('/home'), 3000)
		} catch (error) {
			Toast.toasterror(error.response.data.message)
		}
	}

	return (
		<>
			<ToastContainer></ToastContainer>
			<form
				className='row register-form'
				method='post'
				onSubmit={(e) => loginVolunteer(e)}>
				<div className='col-md-12'>
					<h5 style={{ textAlign: 'left' }}>Email: </h5>
					<div className='form-group'>
						<input
							type='email'
							className='form-control'

							value={email}
							onChange={(e) => setEmail(e.target.value)}
							required
						/>
					</div>
					<div className='form-group'>
						<h5 style={{ textAlign: 'left' }}>Password: </h5>
						<input
							type='password'
							className='form-control'

							value={password}
							onChange={(e) => setPassword(e.target.value)}
							required
						/>
					</div>
				</div>
				<button type='submit' className='btnRegister'
					style={{
						background: '#002db3',
						color: 'white',
						borderRadius: '130px',
						width: '50%',
						height: '100%',
						fontWeight: 'bold',
						letterSpacing: '1px',
					}}
				>
					Login
				</button>
			</form>
		</>
	)
}
export default LoginFormVolunteer
