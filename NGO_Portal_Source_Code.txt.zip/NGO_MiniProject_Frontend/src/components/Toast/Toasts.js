import { toast } from 'react-toastify'
const toastsuccess = (content) => {
	return toast.success(content, {
		position: 'top-center',
		autoClose: 3000,
		hideProgressBar: true,
		pauseOnHover: false,
	})
}

const toasterror = (content) => {
	return toast.error(content, {
		position: 'top-center',
		autoClose: 3000,
		hideProgressBar: true,
		pauseOnHover: false,
	})
}
export default { toastsuccess, toasterror }
