import React from 'react'
import { Link } from 'react-router-dom'
import '../Signup/Signup.css'
const SignupFormLeft = ({ type }) => {
	return (
		<div className='col-md-3 register-left'>
			<img
				src='https://content.jdmagicbox.com/comp/mysore/s6/0821px821.x821.181001194121.e3s6/catalogue/pragathi-organisation-mysore-10oawncrqn.jpg'
				alt=''
			/>
			<h3 style={{color: 'White'}}><strong>Welcome Sir/Ma'am</strong></h3>
			<p style={{color: 'white'}}>We welcome you to join us for a noble cause.
				We are here to help our society by helping NGOs 
				showcase the upcoming events,
				job vacancies and the different fundraising activities.
			</p>
			{type === 'Signup' ? (
				<Link to='/login'>
					<input type='submit' value='Login' />
				</Link>
			) : type === 'Login' ? (
				<Link to='/signup'>
					<input type='submit' value='Sign Up' />
				</Link>
			) : (
				<div></div>
			)}

			<br />
		</div>
	)
}
export default SignupFormLeft
