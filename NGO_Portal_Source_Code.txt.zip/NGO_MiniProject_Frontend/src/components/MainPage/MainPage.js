import React from 'react'
import { Link } from 'react-router-dom'
import './MainPage.css'
import Typewriter from 'typewriter-effect'

const MainPage = () => {
	return (

		// Shows first when you run project
		<div className='main-body'>
			<div className='business-header'>
				<div className='container'>
					<div className='row'>
						<div className='col-lg-12  text-center'>
							<br></br>
							<br></br>
							<br></br>
							<br></br>
							<br></br>
							<br></br>
							<br></br>
							<br></br>
							<hr></hr>
							<h1 className='tagline'>
								<Typewriter
									options={{
										strings: ['Shaping the World', 'Empowering the Future'],
										autoStart: true,
										loop: true,
									}}
								/>
							</h1>
							<hr></hr>
							<br></br>
							<p>
								Let's support the NGOs.
								<br />
								Free access for NGOs to post events, jobs and fundraisers{' '}
							</p>

							<br></br>
							<Link to='/login'>
								<button
									style={{
										background: '#01a6db',
										color: 'white',
										borderRadius: '130px',
										width: '20%',
										marginTop: '2%',
										height: '40px',
										fontSize: '20px',
									}}>
									Let's Go ! »
								</button>
							</Link>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}
export default MainPage
