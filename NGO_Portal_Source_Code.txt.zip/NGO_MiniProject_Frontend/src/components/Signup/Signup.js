import React from 'react'
import './Signup.css'
import SignupFormNgo from './SignupFormNGO'
import SignupFormVolunteer from './SignupFormVolunteer'
import SignupFormLeft from '../SignupandLoginleft/SignupandLoginformLeft'
const Signup = () => {
    return (
        
        <div className='container-fluid register '>
            <div className='row'>
                <SignupFormLeft type='Signup' />
              
                <div className='col-md-9 register-right'>
                    <ul className='nav nav-tabs nav-justified'
                        
                        id='myTab' role='tablist'>
                        <li className='nav-item'>
                            <a
                                className='nav-link active'
                                id='home-tab'
                                data-toggle='tab'
                                href='#home'
                                role='tab'
                                aria-controls='home'
                                aria-selected='true'>
                                NGO
							</a>
                        </li>
                        <li className='nav-item'>
                            <a
                                className='nav-link'
                                id='profile-tab'
                                data-toggle='tab'
                                href='#profile'
                                role='tab'
                                aria-controls='profile'
                                aria-selected='false'>
                                Volunteer
							</a>
                        </li>
                    </ul>
                    <div className='tab-content' id='myTabContent'>
                        <div
                            className='tab-pane fade show active'
                            id='home'
                            role='tabpanel'
                            aria-labelledby='home-tab'>
                            <h3 className='register-heading'>Register as an <strong>NGO</strong></h3>
                            <SignupFormNgo />
                         
                        </div>
                        <div
                            className='tab-pane fade show'
                            id='profile'
                            role='tabpanel'
                            aria-labelledby='profile-tab'>
                            <h3 className='register-heading'>Register as a <strong>Volunteer</strong></h3>
                            <SignupFormVolunteer />
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Signup
