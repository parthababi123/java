import React, { useState, useContext } from 'react'
import './Signup.css'
import { ToastContainer } from 'react-toastify'
import Toast from '../Toast/Toasts'
import NGOservice from '../../services/NGOservice'
import { UserContext } from '../../App'
import { useHistory } from 'react-router-dom'
import jwt_decode from 'jwt-decode'
const myStyle = {
	color: 'red',
	fontSize: '11px'
}
const SignupFormNgo = () => {

	// Passing Values to DB using Axios
	// Using JavaScript for Validation 

	const { state, dispatch } = useContext(UserContext)
	const history = useHistory()

	const [name, setName] = useState('')
	const [email, setEmail] = useState('')
	const [password, setPassword] = useState('')
	const [websiteLink, setWebsiteLink] = useState('')
	const [address1, setAddress1] = useState('')
	const [address2, setAddress2] = useState('')
	const [regid, setRegID] = useState('')
	const [contact, setContact] = useState(0)
	const [zipcode, setZipcode] = useState(0)
	const [city, setCity] = useState('')
	const [ngostate, setNgoState] = useState('')

	const signupNgo = async (e) => {
		e.preventDefault()
		const ngoForm = {
			ngoEmail: email,
			ngoPassword: password,
			ngoName: name,
			ngoURL: websiteLink,
			ngoRegID: regid,
			ngoAddress1: address1,
			ngoAddress2: address2,
			ngoZipCode: Number(zipcode),
			ngoCity: city,
			ngoState: ngostate,
			ngoContact: Number(contact),
		}
		const validate = () => {
			let ngoEmail = email;
			let ngoPassword = password;
			let ngoName = name;
			let ngoRegID = Number(regid);
			let ngoZipCode = Number(zipcode);
			let ngoContact = Number(contact);
			let emailError = '';
			let passwordError = '';
			let contactError = '';
			let nameError = '';
			let zipCodeError = '';
			let email_regx = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]{3,})*$/;
			let pass_regx = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
			let contact_regx = /^\d{10}$/;
			let name_regx = /^[A-Za-z]+$/;
			let zipCode_regx = /^\d{6}$/;
			if (!email_regx.test(ngoEmail)) {
				emailError = 'Please input your correct email';
			} if (!pass_regx.test(ngoPassword)) {
				passwordError = 'The password should include both upper and lower case letters, and atleast one numerical value and special character';
			} if (!contact_regx.test(ngoContact)) {
				contactError = 'The contact should be of 10 digits';
			} if (!name_regx.test(ngoName)) {
				nameError = 'Your first name should consist of only letters and of length six';
			} if (!zipCode_regx.test(ngoZipCode)) {
				zipCodeError = 'The Zip Code should be of contain only six numeric digits';
			} if (emailError || passwordError || contactError || nameError || zipCodeError) {
				document.getElementById('error-email').innerHTML = emailError;
				document.getElementById('error-password').innerHTML = passwordError;
				document.getElementById('error-contact').innerHTML = contactError;
				document.getElementById('error-name').innerHTML = nameError;
				document.getElementById('error-code').innerHTML = zipCodeError;
				return false;
			}
			else {
				return true;
			}
		}
		if (validate()) {
			try {
				// console.log(ngoForm)
				const res = await NGOservice.signup(ngoForm)
				// console.log(res)

				const token = res.token
				localStorage.setItem('token', token)
				const user = jwt_decode(token)
				localStorage.setItem('user', JSON.stringify(user))
				dispatch({ type: 'USER', payload: user })
				localStorage.setItem('ngoEmail', user.ngoEmail)
				localStorage.setItem('ngoName', user.ngoName)
				localStorage.setItem('ngoRegID', user.ngoRegID)
				localStorage.setItem('ngoContact', user.ngoContact)
				setAddress1('')
				setAddress2('')
				setCity('')
				setNgoState('')
				setContact(0)
				setEmail('')
				setName('')
				setPassword('')
				setRegID('')
				setZipcode(0)
				setWebsiteLink('')
				Toast.toastsuccess(res.message)

				setInterval(() => history.push('/ngohome'), 3000)
			} catch (error) {
				// console.log(error)
				Toast.toasterror(error.response.data.message)
			}
		}
	}

	return (
		<>
			<ToastContainer></ToastContainer>
			<form
				className='row register-form'
				method='post'
				onSubmit={(e) => signupNgo(e)}>
				<div className=' col-md-6'>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>NGO Name*</h6>

						<input
							type='text'
							className='form-control'
							value={name}
							onChange={(e) => setName(e.target.value)}
							required
						/>
						<p id='error-name' style={myStyle}></p>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Email*</h6>

						<input
							type='email'
							className='form-control'
							value={email}
							onChange={(e) => setEmail(e.target.value)}
							required
						/>
						<p id='error-email' style={myStyle}></p>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Password*</h6>

						<input
							type='password'
							className='form-control'
							value={password}
							onChange={(e) => setPassword(e.target.value)}
							required
						/>
						<p id='error-password' style={myStyle}></p>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Website</h6>

						<input
							type='text'
							className='form-control'
							value={websiteLink}
							onChange={(e) => setWebsiteLink(e.target.value)}
						/>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>City*</h6>

						<input
							type='text'
							className='form-control'
							value={city}
							onChange={(e) => setCity(e.target.value)}
							required
						/>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>State*</h6>

						<input
							type='text'
							className='form-control'
							value={ngostate}
							onChange={(e) => setNgoState(e.target.value)}
							required
						/>
					</div>
				</div>
				<div className='col-md-6'>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Reg. ID*</h6>

						<input
							type='number'
							className='form-control'
							value={regid}
							onChange={(e) => setRegID(e.target.value)}
							required
						/>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Contact*</h6>

						<input
							type='number'
							className='form-control'
							minLength={10}
							maxLength={10}
							value={contact === 0 ? '' : contact}
							onChange={(e) => setContact(e.target.value)}
							required
						/>
						<p id='error-contact' style={myStyle}></p>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Address 1*</h6>

						<input
							type='text'
							className='form-control'
							value={address1}
							required
							onChange={(e) => setAddress1(e.target.value)}
						/>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Address 2*</h6>

						<input
							type='text'
							className='form-control'
							value={address2}
							required
							onChange={(e) => setAddress2(e.target.value)}
						/>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Zip Code*</h6>

						<input
							type='number'
							className='form-control'
							value={zipcode === 0 ? '' : zipcode}
							required
							onChange={(e) => setZipcode(e.target.value)}
						/>
						<p id='error-code' style={myStyle}></p>
					</div>
				</div>
				<button type='submit' className='btnRegister'
					style={{
						background: '#002db3',
						color: 'white',
						borderRadius: '130px',
						width: '50%',
						height: '100%',
						fontWeight: 'bold',
						letterSpacing: '1px',
					}}
				>
					Register
				</button>
			</form>
		</>
	)
}
export default SignupFormNgo
