import React, { useState, useContext } from 'react'
import Volunteerservice from '../../services/Volunteerservice'
import Toast from '../Toast/Toasts'
import './Signup.css'
import { ToastContainer } from 'react-toastify'
import { UserContext } from '../../App'
import { useHistory } from 'react-router-dom'
import jwt_decode from 'jwt-decode'

const myStyle = {
	color: 'red',
	fontSize: '11px'
}

const SignupFormVolunteer = () => {
	const { state, dispatch } = useContext(UserContext)
	const history = useHistory()

	const [dob, setDOB] = useState('')
	const [fname, setFname] = useState('')
	const [mname, setMname] = useState('')
	const [lname, setLname] = useState('')
	const [email, setEmail] = useState('')
	const [password, setPassword] = useState('')
	const [contact, setContact] = useState(0)

	const signupVolunteer = async (e) => {
		e.preventDefault()
		// e.preventDefault()
		const volunteerForm = {
			userEmail: email,
			userPassword: password,
			userFirstName: fname,
			userMidName: mname,
			userLastName: lname,
			userContact: Number(contact),
			userDOB: dob,
		}
		const validate = () => {
			let userEmail = email;
			let userPassword = password;
			let userFirstName = fname;
			let userLastName = lname;
			let userContact = Number(contact);
			let emailError = '';
			let passwordError = '';
			let contactError = '';
			let firstNameError = '';
			let lastNameError = '';
			let email_regx = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]{3,})*$/;
			let pass_regx = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
			let contact_regx = /^\d{10}$/;
			let name_regx = /^[A-Za-z]+$/;
			if (!email_regx.test(userEmail)) {
				emailError = 'Please input your correct email';
			} if (!pass_regx.test(userPassword)) {
				passwordError = 'The password should include both upper and lower case letters, and atleast one numerical value and special character';
			} if (!contact_regx.test(userContact)) {
				contactError = 'The contact should be of 10 digits';
			} if (!name_regx.test(userFirstName) || (userFirstName.length < 6)) {
				firstNameError = 'Your first name should consist of only letters and of length six';
			} if (!name_regx.test(userLastName) || (userLastName.length < 6)) {
				lastNameError = 'Your last name should consist of only letters and of length six';
			} if (emailError || passwordError || contactError || firstNameError || lastNameError) {
				document.getElementById('error-email').innerHTML = emailError;
				document.getElementById('error-password').innerHTML = passwordError;
				document.getElementById('error-contact').innerHTML = contactError;
				document.getElementById('error-fname').innerHTML = firstNameError;
				document.getElementById('error-lname').innerHTML = lastNameError;
				return false;
			}
			else {
				return true;
			}
		}
		if (validate()) {
			try {
				const res = await Volunteerservice.signup(volunteerForm)
				const token = res.token
				localStorage.setItem('token', token)
				const user = jwt_decode(token)

				localStorage.setItem('user', JSON.stringify(user))
				dispatch({ type: 'USER', payload: user })
				localStorage.setItem('userEmail', user.userEmail)
				localStorage.setItem('userName', user.userFirstName)
				localStorage.setItem('userLName', user.userLastName)
				localStorage.setItem('userContact', user.userContact)
				localStorage.setItem('DOB', user.userDOB)
				setContact(0)
				setDOB('')
				setEmail('')
				setFname('')
				setLname('')
				setMname('')
				setPassword('')
				Toast.toastsuccess(res.message)

				setInterval(() => history.push('/home'), 3000)
			} catch (error) {
				Toast.toasterror(error.response.data.message)
			}
		}
	}

	return (
		<>
			<ToastContainer></ToastContainer>
			<form
				className='row register-form'
				method='post'
				onSubmit={(e) => signupVolunteer(e)}>
				<div className='col-md-6'>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>First Name*</h6>

						<input
							type='text'
							className='form-control'
							value={fname}
							onChange={(e) => setFname(e.target.value)}

							required='required'
						/>
						<p id='error-fname' style={myStyle}></p>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Last Name*</h6>

						<input
							type='text'
							className='form-control'
							value={lname}
							onChange={(e) => setLname(e.target.value)}

							required='required'
						/>
						<p id='error-lname' style={myStyle}></p>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Email*</h6>

						<input
							type='email'
							className='form-control'
							value={email}
							onChange={(e) => setEmail(e.target.value)}

						/>
						<p id='error-email' style={myStyle}></p>
					</div>

					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>DOB*</h6>

						<input
							type='text'
							className='form-control'

							required
							value={dob}
							onFocus={(e) => (e.target.type = 'date')}
							onBlur={(e) => (e.target.type = 'text')}
							onChange={(e) => setDOB(e.target.value)}
						/>
					</div>
				</div>
				<div className='col-md-6'>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Middle Name</h6>

						<input
							type='text'
							value={mname}
							onChange={(e) => setMname(e.target.value)}
							className='form-control'

						/>

					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Contact*</h6>

						<input
							type='number'
							minLength={10}
							maxLength={10}
							className='form-control'

							value={contact === 0 ? '' : contact}
							onChange={(e) => setContact(e.target.value)}
							required='required'
						/>
						<p id='error-contact' style={myStyle}></p>
					</div>
					<div className='form-group'>
						<h6 style={{ textAlign: 'left' }}>Password*</h6>

						<input
							type='password'
							className='form-control'

							value={password}
							onChange={(e) => setPassword(e.target.value)}
							required='required'
						/>
						<p id='error-password' style={myStyle}></p>
					</div>
				</div>
				<button type='submit' className='btnRegister'
					style={{
						background: '#002db3',
						color: 'white',
						borderRadius: '130px',
						width: '50%',
						height: '100%',
						fontWeight: 'bold',
						letterSpacing: '1px',
					}}
				>
					Register
				</button>
			</form>
		</>
	)
}
export default SignupFormVolunteer
