import React, { useEffect, createContext, useReducer, useContext } from 'react'
import { BrowserRouter, Route, Switch, useHistory } from 'react-router-dom'
import './App.css'
import Signup from './components/Signup/Signup'
import { reducer, initialState } from './reducers/userReducer'
import Login from './components/Login/Login'
import EndUserHomePage from './components/HomePage/EndUser/EndUserHomePage'
import NGOHomePage2 from './components/HomePage/NGOUser/NGOHomePage2'
import MainPage from './components/MainPage/MainPage'
import UserProfile from './components/HomePage/EndUser/UserProfile'
export const UserContext = createContext()

const Routing = () => {
	const history = useHistory()
	const { state, dispatch } = useContext(UserContext)
	useEffect(() => {
		const user = JSON.parse(localStorage.getItem('user'))
		if (user) {
			dispatch({ type: 'USER', payload: user })
		} else {
			if (
				!history.location.pathname.startsWith('/signup') &&
				!history.location.pathname.startsWith('/login')
			)
				history.push('/')
		}
	}, [])
	return (
		<Switch>
			<Route exact path='/'>
				<MainPage />
			</Route>
			<Route path='/signup'>
				<Signup />
			</Route>
			<Route path='/login'>
				<Login />
			</Route>
			<Route path='/home'>
				<EndUserHomePage />
			</Route>
			<Route path='/userprofile'>
				<UserProfile />
			</Route>
			<Route path='/ngohome'>
				<NGOHomePage2 />
			</Route>
		</Switch>
	)
}
function App() {
	const [state, dispatch] = useReducer(reducer, initialState)
	return (
		<UserContext.Provider value={{ state, dispatch }}>
			<BrowserRouter>
				<Routing />
			</BrowserRouter>
		</UserContext.Provider>
	)
}
export default App
