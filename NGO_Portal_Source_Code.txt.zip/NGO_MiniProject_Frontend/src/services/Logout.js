const logout = () => {
	localStorage.clear()
}

export default { logout }
