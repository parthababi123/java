import axios from 'axios'
let token = null

const setToken = (newToken) => {
	token = newToken
}
const baseUrl = '/user'

const signup = async (volunteerForm) => {
	const response = await axios.post(`${baseUrl}/signup`, volunteerForm)
	return response.data
}

const login = async (volunteerForm) => {
	const response = await axios.post(`${baseUrl}/login`, volunteerForm)
	return response.data
}

const getAllJobs = async () => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}
	const response = await axios.get(`${baseUrl}/home/homepage/jobs`, config)
	return response.data
}

const getAllEvents = async () => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}
	const response = await axios.get(`${baseUrl}/home/homepage/events`, config)
	return response.data
}
const getAllFundRaisers = async () => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}
	const response = await axios.get(`${baseUrl}/home/homepage/funds`, config)
	return response.data
}

const jobApply = async (jobForm) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}
	const response = await axios.post(
		`${baseUrl}/home/homepage/jobs/register`,
		jobForm,
		config
	)
	return response.data
}

const eventRegister = async (eventForm) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}
	const response = await axios.post(
		`${baseUrl}/home/homepage/events/register`,
		eventForm,
		config
	)
	return response.data
}

const volunteerJobs = async (userEmail) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}

	const response = await axios.get(
		`${baseUrl}//home/homepage/profile/myjobs/${userEmail}`,
		config
	)
	return response.data
}

const volunteerEvents = async (userEmail) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}

	const response = await axios.get(
		`${baseUrl}//home/homepage/profile/myevents/${userEmail}`,
		config
	)
	return response.data
}

const volunteerFRs = async (userEmail) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}

	const response = await axios.get(
		`${baseUrl}//home/homepage/profile/myfundraisers/${userEmail}`,
		config
	)
	return response.data
}
export default {
	setToken,
	signup,
	login,
	getAllFundRaisers,
	getAllJobs,
	getAllEvents,
	jobApply,
	eventRegister,
	volunteerEvents,
	volunteerFRs,
	volunteerJobs,
}
