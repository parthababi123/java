import axios from 'axios'
let token = null

const setToken = (newToken) => {
	token = newToken
}
const baseUrl = '/ngo'

const signup = async (ngoForm) => {
	const response = await axios.post(`${baseUrl}/signup`, ngoForm)

	return response.data
}

const login = async (ngoForm) => {
	const response = await axios.post(`${baseUrl}/login`, ngoForm)
	console.log('debug'+ baseUrl);
	return response.data
}

const addJob = async (jobInfo) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}
	const response = await axios.post(`${baseUrl}/home/job`, jobInfo, config)
	return response.data
}

const addEvent = async (eventInfo) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}
	const response = await axios.post(`${baseUrl}/home/event`, eventInfo, config)
	return response.data
}

const addFundRaiser = async (fundInfo) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}
	const response = await axios.post(`${baseUrl}/home/fund`, fundInfo, config)
	return response.data
}


const getMyJobs = async (ngoEmail) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}

	const response = await axios.get(
		`${baseUrl}/home/homepage/myjobs/${ngoEmail}`,
		config
	)
	return response.data
}

const getMyEvents = async (ngoEmail) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}

	const response = await axios.get(
		`${baseUrl}/home/homepage/myevents/${ngoEmail}`,
		config
	)
	return response.data
}
const getMyFRs = async (ngoEmail) => {
	const config = {
		headers: { Authorization: 'Bearer ' + token },
	}

	const response = await axios.get(
		`${baseUrl}/home/homepage/myfundraisers/${ngoEmail}`,
		config
	)
	return response.data
}
export default {
	setToken,
	signup,
	login,
	addEvent,
	addJob,
	addFundRaiser,
	getMyJobs,
	getMyEvents,
	getMyFRs,
}

