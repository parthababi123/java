package com.ngoportal.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class NgoUserAuthException extends RuntimeException{
    public NgoUserAuthException(String message) {super(message);}
}
