package com.ngoportal.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class EndUserAuthException extends RuntimeException{
    public EndUserAuthException(String message) {
        super(message);
    }
}
