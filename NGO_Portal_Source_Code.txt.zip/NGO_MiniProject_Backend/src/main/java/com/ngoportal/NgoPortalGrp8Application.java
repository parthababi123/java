package com.ngoportal;

import com.ngoportal.filters.EndUserAuthFilter;
import com.ngoportal.filters.NgoUserAuthFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class NgoPortalGrp8Application {

	public static void main(String[] args) {
		SpringApplication.run(NgoPortalGrp8Application.class, args);
	}

	@Bean
	public FilterRegistrationBean<EndUserAuthFilter> endUserFilterRegistrationBean() {
		FilterRegistrationBean<EndUserAuthFilter> registrationBean = new FilterRegistrationBean<>();
		EndUserAuthFilter authFilter = new EndUserAuthFilter();
		registrationBean.setFilter(authFilter);
		registrationBean.addUrlPatterns("/user/home/*"); //url patterns that will need JWT token
		return registrationBean;
	}

	@Bean
	public FilterRegistrationBean<NgoUserAuthFilter> ngoUserFilterRegistrationBean() {
		FilterRegistrationBean<NgoUserAuthFilter> registrationBean = new FilterRegistrationBean<>();
		NgoUserAuthFilter authFilter = new NgoUserAuthFilter();
		registrationBean.setFilter(authFilter);
		registrationBean.addUrlPatterns("/ngo/home/*"); //url patterns that will need JWT token
		return registrationBean;
	}

}
