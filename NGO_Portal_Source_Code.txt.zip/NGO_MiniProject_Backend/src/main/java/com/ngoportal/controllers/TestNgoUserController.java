package com.ngoportal.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/ngo/home")
public class TestNgoUserController {
    @GetMapping("")
    public String testJWTToken(HttpServletRequest request) {
        String ngoEmail = (String) request.getAttribute("ngoEmail");
        return "Authenticated! ngo email: " + ngoEmail;
    }
}
