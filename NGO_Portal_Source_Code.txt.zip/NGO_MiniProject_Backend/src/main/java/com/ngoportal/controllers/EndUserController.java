package com.ngoportal.controllers;

import com.ngoportal.Constants;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ngoportal.models.EndUser;
import com.ngoportal.models.EndUserResponse;
import com.ngoportal.models.Login;
import com.ngoportal.services.EndUserService;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = "/user")
public class EndUserController {
	@Autowired
	EndUserService service;

	@PostMapping(value = "/login")
	public ResponseEntity<Map<String, String>> loginEndUser(@RequestBody Map<String, Object> userMap) {
		// service.checkCredentials(user.getEmail(), user.getPassword());

		String email = (String) userMap.get("email");
		String password = (String) userMap.get("password");
		EndUser endUser = service.checkCredentials(email, password);
		Map<String, String> map = new HashMap<>();
		map.put("token", generateJWTToken(endUser));
		map.put("message", "User logged in successfully");
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@PostMapping(value = "/signup")
	public ResponseEntity<Map<String, String>> createNewEndUser(@RequestBody Map<String, Object> userMap) {
		// service.addEndUser(endUser);

		String email = (String) userMap.get("userEmail");
		String password = (String) userMap.get("userPassword");
		String firstName = (String) userMap.get("userFirstName");
		String middleName = (String) userMap.get("userMidName");
		String lastName = (String) userMap.get("userLastName");
		long contact = (long) userMap.get("userContact");
		String DOB = (String) userMap.get("userDOB");

		EndUser endUser = service.addEndUser(email, password, firstName, middleName, lastName, contact, DOB);
		Map<String, String> map = new HashMap<>();
		map.put("token", generateJWTToken(endUser));
		map.put("message", "User signed up successfully");
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	// Token will be generated for the user which will be provided as parameter and
	// returns map of string
	private String generateJWTToken(EndUser endUser) {
		long timestamp = System.currentTimeMillis(); // current time in milliseconds

		// Token is configured using this builder method
		String token = Jwts.builder().signWith(SignatureAlgorithm.HS256, Constants.API_SECRET_KEY)
				.setIssuedAt(new Date(timestamp)).setExpiration(new Date(timestamp + Constants.TOKEN_VALIDITY))
				.claim("userEmail", endUser.getUserEmail()) // Custom user specific data along with token (if needed)
				.claim("userFirstName", endUser.getUserFirstName()).claim("userMidName", endUser.getUserMidName())
				.claim("userLastName", endUser.getUserLastName()).claim("userContact", endUser.getUserContact())
				.claim("userDOB", endUser.getUserDOB()).compact(); // builds the token
		return token;
	}

//	@GetMapping(value = "/home/homepage/events")
//	public ResponseEntity<Map<Object, Object>> getAllEvents() {
//		return new ResponseEntity<Map<Object, Object>>(service.getAllEventMap(), HttpStatus.OK);
//
//	}

	@GetMapping(value = "/home/homepage/jobs")
	public ResponseEntity<Map<Object, Object>> getAllJobs() {
		return new ResponseEntity<Map<Object, Object>>(service.getAllJobMap(), HttpStatus.OK);
	}

	@GetMapping(value = "/home/homepage/funds")
	public ResponseEntity<Map<Object, Object>> getAllFundraiser() {
		return new ResponseEntity<Map<Object, Object>>(service.getAllFundraiserMap(), HttpStatus.OK);
	}

	@GetMapping(value = "/home/homepage/events")
	public ResponseEntity<Map<Object, Object>> getAllEvents() // For EndUser Homepage to show all events
	{
		return new ResponseEntity<Map<Object, Object>>(service.getAllEventMap(), HttpStatus.OK);

	}

	@GetMapping(value="/home/homepage/profile/myevents/{userEmail}")
	public ResponseEntity<Map<Object, Object>> getMyEvents(@PathVariable("userEmail") String userEmail)
	{
		return new ResponseEntity<Map<Object,Object>>(service.getMyEventsMap(userEmail), HttpStatus.OK);
	}

	@GetMapping(value="/home/homepage/profile/myjobs/{userEmail}")
	public ResponseEntity<Map<Object, Object>> getMyJobs(@PathVariable("userEmail") String userEmail)
	{
		return new ResponseEntity<Map<Object,Object>>(service.getMyJobsMap(userEmail), HttpStatus.OK);
	}

	@GetMapping(value="/home/homepage/profile/myfundraisers/{userEmail}")
	public ResponseEntity<Map<Object, Object>> getMyFundraisers(@PathVariable("userEmail") String userEmail)
	{
		return new ResponseEntity<Map<Object,Object>>(service.getMyFundraisersMap(userEmail), HttpStatus.OK);
	}

//	@GetMapping(value = "/home/homepage/jobs")
//	public ResponseEntity<Map<Object, Object>> getAllJobs() // For EndUser Homepage to show all jobs
//	{
//		return new ResponseEntity<Map<Object, Object>>(service.getAllJobMap(), HttpStatus.OK);
//	}
//
//	@GetMapping(value = "/home/homepage/funds")
//	public ResponseEntity<Map<Object, Object>> getAllFundraiser() // For EndUser Homepage to show all jobs
//	{
//		return new ResponseEntity<Map<Object, Object>>(service.getAllFundraiserMap(), HttpStatus.OK);
//	}

	@PostMapping(value = "/home/homepage/events/register")
	public ResponseEntity<Map<Object, Object>> registerForEvent(@RequestBody EndUserResponse response) // To be called
																										// when register
																										// button on
																										// event UI is
																										// clicked
	{
		return new ResponseEntity<Map<Object, Object>>(service.getEventRegistrationMap(response), HttpStatus.OK);

	}

	@PostMapping(value = "/home/homepage/jobs/register")
	public ResponseEntity<Map<Object, Object>> applyForJob(@RequestBody EndUserResponse response) // To be called when
																									// apply button on
																									// job UI is clicked
	{
		return new ResponseEntity<Map<Object, Object>>(service.getJobRegistrationMap(response), HttpStatus.OK);

	}
}
