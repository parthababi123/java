package com.ngoportal.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/user/home")
public class TestEndUserController {

    @GetMapping("")
    public String testJWTToken(HttpServletRequest request) {
        String userEmail = (String) request.getAttribute("userEmail");
        return "Authenticated! user email: " + userEmail;
    }
}
