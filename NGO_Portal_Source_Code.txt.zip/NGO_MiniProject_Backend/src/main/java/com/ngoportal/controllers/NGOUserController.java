package com.ngoportal.controllers;

import com.ngoportal.Constants;
import com.ngoportal.models.*;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ngoportal.services.NGOUserService;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value="/ngo")
public class NGOUserController {

	@Autowired
	NGOUserService service;

	@PostMapping(value="/login")
	public ResponseEntity<Map<String, String>> loginNGOUser(@RequestBody Map<String, String> userMap)
	{
		//service.checkCredentials(user.getEmail(), user.getPassword());

		String email = (String) userMap.get("email");
		String password = (String) userMap.get("password");
		NGOUser ngoUser = service.checkCredentials(email, password);
		Map<String, String> map = new HashMap<>();
		map.put("token", generateJWTToken(ngoUser));
		map.put("message", "User logged in successfully");
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@PostMapping(value="/signup")
	public ResponseEntity<Map<String, String>> createNewNGOUser(@RequestBody Map<String, Object> userMap)
	{
		//service.addNgoUser(ngoUser);

		String email = (String) userMap.get("ngoEmail");
		String password = (String) userMap.get("ngoPassword");
		String name = (String) userMap.get("ngoName");
		String url = (String) userMap.get("ngoURL");
		String regID = (String) userMap.get("ngoRegID");
		String address1 = (String) userMap.get("ngoAddress1");
		String address2 = (String) userMap.get("ngoAddress2");
		int zipcode = (int) userMap.get("ngoZipCode");
		String city  = (String) userMap.get("ngoCity");
		String state = (String) userMap.get("ngoState");
		long contact = (long) userMap.get("ngoContact");

		NGOUser ngoUser = service.addNGOUser(email, password, name, url, regID, address1, address2, zipcode,
				city, state, contact);
		Map<String, String> map = new HashMap<>();
		map.put("token", generateJWTToken(ngoUser));
		map.put("message", "User signed up successfully");
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@PostMapping(value="/home/event")
	public ResponseEntity<Map<Object, Object>> createNewEvent(@RequestBody NGOEvent event)
	{
		Map<Object, Object> map=service.addNewEvent(event);
		return new ResponseEntity<Map<Object, Object>>(map, HttpStatus.OK);
	}
	@PostMapping(value="/home/job")
	public ResponseEntity<Map<Object, Object>> createNewJob(@RequestBody NGOJob job)
	{
		Map<Object, Object> map = service.addNewJob(job);

		return new ResponseEntity<Map<Object , Object>>(map, HttpStatus.OK);
	}
	@PostMapping(value="/home/fund")
	public ResponseEntity<Map<Object, Object>> createNewFundraiser(@RequestBody NGOFundRaiser fundRaiser)
	{
		Map<Object, Object> map = service.addNewFundraiser(fundRaiser);
		return new ResponseEntity<Map<Object, Object>>(map, HttpStatus.OK);
	}

	//Token will be generated for the user which will be provided as parameter and returns map of string
	private String generateJWTToken(NGOUser ngoUser) {
		long timestamp = System.currentTimeMillis(); //current time in milliseconds

		//Token is configured using this builder method
		String token = Jwts.builder().signWith(SignatureAlgorithm.HS256, Constants.API_SECRET_KEY)
				.setIssuedAt(new Date(timestamp))
				.setExpiration(new Date(timestamp + Constants.TOKEN_VALIDITY))
				.claim("ngoEmail", ngoUser.getNgoEmail()) //Custom user specific data along with token (if needed)
				.claim("ngoName", ngoUser.getNgoName())
				.claim("ngoURL", ngoUser.getNgoRegId())
				.claim("ngoRegID", ngoUser.getNgoRegId())
				.claim("ngoAddressLine1", ngoUser.getNgoAddress1())
				.claim("ngoAddressLine2", ngoUser.getNgoAddress2())
				.claim("ngoZipCode", ngoUser.getNgoZipCode())
				.claim("ngoCity", ngoUser.getNgoCity())
				.claim("ngoState", ngoUser.getNgoState())
				.claim("ngoContact", ngoUser.getNgoContact())
				.compact(); //builds the token
		return token;
	}

	@GetMapping(value="/home/homepage/myevents/{ngoEmail}") // Method to get all events for a NGO
	public ResponseEntity<Map<Object, Object>> getMyEventResponses(@PathVariable("ngoEmail") String ngoEmail)
	{
		return new ResponseEntity<Map<Object,Object>>(service.getMyEventResponsesMap(ngoEmail), HttpStatus.OK);
	}

	@GetMapping(value="/home/homepage/myjobs/{ngoEmail}") // Method to get all jobs for a NGO
	public ResponseEntity<Map<Object, Object>> getMyJobResponses(@PathVariable("ngoEmail") String ngoEmail)
	{
		return new ResponseEntity<Map<Object,Object>>(service.getMyJobResponsesMap(ngoEmail), HttpStatus.OK);
	}

	@GetMapping(value = "/home/homepage/myfundraisers/{ngoEmail}") // Method to get all fundraisers for a NGO
	public ResponseEntity<Map<Object, Object>> getMyFundRaiserResponses(@PathVariable("ngoEmail") String ngoEmail)
	{

		return new ResponseEntity<Map<Object, Object>>(service.getMyFundraiserResponsesMap(ngoEmail), HttpStatus.OK);
	}
	
}
