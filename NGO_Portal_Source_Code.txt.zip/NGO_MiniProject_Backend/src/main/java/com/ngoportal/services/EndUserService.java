package com.ngoportal.services;

import com.ngoportal.exceptions.EndUserAuthException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DaoSupport;
import org.springframework.stereotype.Service;

import com.ngoportal.dao.EndUserDAO;
import com.ngoportal.models.EndUser;
import com.ngoportal.models.EndUserResponse;
import com.ngoportal.models.NGOEvent;
import com.ngoportal.models.NGOFundRaiser;
import com.ngoportal.models.NGOJob;

import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

@Service
@Transactional
public class EndUserService {

	@Autowired
	EndUserDAO dao;

	public EndUser addEndUser(String userEmail, String userPassword, String userFirstName, String userMiddleName,
			String userLastName, long userContact, String userDOB) {
		// dao.saveEndUser(endUser);
		Pattern pattern = Pattern.compile("^(.+)@(.+)$");
		if (userEmail != null)
			userEmail = userEmail.toLowerCase();
		if (!pattern.matcher(userEmail).matches())
			throw new EndUserAuthException("Invalid Email Format");
		Integer count = dao.getCountByEmail(userEmail);
		if (count > 0)
			throw new EndUserAuthException("Email already in use");
		try {
			EndUser endUser = dao.saveEndUser(userEmail, userPassword, userFirstName, userMiddleName, userLastName,
					userContact, userDOB);
			return endUser;
		} catch (Exception e) {
			throw new EndUserAuthException(e + "");
		}

	}

	public EndUser checkCredentials(String email, String password) {
		// dao.isLoginCredentialsValid(String email, String password);

		if (email != null)
			email = email.toLowerCase();
		return dao.isLoginCredentialsValid(email, password);
	}

	public Map<Object, Object> getAllEventMap() {
		Map<Object, Object> map = new HashMap<Object, Object>();

		List<NGOEvent> list = dao.getEventList();

		System.out.println(list.size());

		if (list.size() == 0) {
			map.put("message", "No Upcoming Events, Please Try Later!");
			return map;
		} else {
			map.put("events", list);
			return map;
		}
	}

	public Map<Object, Object> getAllJobMap() {
		List<NGOJob> list = dao.getJobList();

		Map<Object, Object> map = new HashMap<Object, Object>();

		if (list.size() == 0) {
			map.put("message", "No Job Openings Available Currently, Please Try Later");
			return map;
		} else {
			map.put("jobs", list);
			return map;
		}
	}

	public Map<Object, Object> getAllFundraiserMap() {
		List<NGOFundRaiser> list = dao.getFundraiserList();

		Map<Object, Object> map = new HashMap<Object, Object>();

		if (list.size() == 0) {
			map.put("message", "No Fundraisers Currently, Please Try Later");
			return map;
		} else {
			map.put("funds", list);
			return map;
		}
	}

	public Map<Object, Object> getEventRegistrationMap(EndUserResponse response) {
		Boolean result = dao.saveEventRegistration(response.getId(), response.getUserEmail());

		Map<Object, Object> map = new HashMap<Object, Object>();

		if (result) {
			map.put("message", "Registered successfully!");
			return map;
		} else {
			map.put("message", "Some Error has Occured, Please try again");
			return map;
		}
	}

	public Map<Object, Object> getJobRegistrationMap(EndUserResponse response) {
		Map<Object, Object> map = new HashMap<Object, Object>();

		Boolean result = dao.saveJobRegistration(response.getId(), response.getUserEmail());

		if (result) {
			map.put("message", "Applied succefully!");
			return map;
		} else {
			map.put("message", "Some Error has Occured, Please Try Again");
			return map;
		}
	}

	public Map<Object, Object> getMyJobsMap(String userEmail) {
		List<NGOJob> list = dao.getMyJobsList(userEmail);

		Map<Object, Object> map = new HashMap<Object, Object>();

		if (list.size() == 0) {
			map.put("message", "You have not applied for any job");
			return map;
		} else {
			map.put("myjobs", list);
			return map;
		}
	}

	public Map<Object, Object> getMyFundraisersMap(String userEmail)
	{
		List<NGOFundRaiser> list = dao.getMyFundraisersList(userEmail);

		Map<Object, Object> map = new HashMap<Object, Object> ();

		if(list.size()==0)
		{
			map.put("message", "You have not donated to any fundraiser");
			return map;
		}
		else
		{
			map.put("myfundraisers", list);
			return map;
		}
	}

	public Map<Object, Object> getMyEventsMap(String userEmail)
	{
		List<NGOEvent> list=dao.getMyEventsList(userEmail);

		Map<Object, Object> map =new HashMap<Object, Object> ();

		if(list.size()==0)
		{
			map.put("message", "You have not registered for any event");
			return map;
		}
		else
		{
			map.put("myevents", list);
			return map;
		}
	}
}
