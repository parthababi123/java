package com.ngoportal.services;

import com.ngoportal.NgoPortalGrp8Application;
import com.ngoportal.exceptions.EndUserAuthException;
import com.ngoportal.exceptions.NgoUserAuthException;
import com.ngoportal.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ngoportal.dao.NGOUserDAO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

@Service
public class NGOUserService {

	@Autowired
	NGOUserDAO dao;

	public NGOUser addNGOUser(String ngoEmail, String ngoPassword, String ngoName, String ngoURL, String ngoRegID,
			String ngoAddress1, String ngoAddress2, int ngoZipCode, String ngoCity, String ngoState, long ngoContact) {
		// dao.saveNGOUser(ngoUser);

		Pattern pattern = Pattern.compile("^(.+)@(.+)$");
		if (ngoEmail != null)
			ngoEmail = ngoEmail.toLowerCase();
		if (!pattern.matcher(ngoEmail).matches())
			throw new NgoUserAuthException("Invalid Email Format");
		Integer count = dao.getCountByEmail(ngoEmail);
		if (count > 0)
			throw new NgoUserAuthException("Email already in use");
		try {
			NGOUser ngoUser = dao.saveNGOUser(ngoEmail, ngoPassword, ngoName, ngoURL, ngoRegID, ngoAddress1,
					ngoAddress2, ngoZipCode, ngoCity, ngoState, ngoContact);
			return ngoUser;
		} catch (Exception e) {
			throw new EndUserAuthException(e + "");
		}
	}

	public NGOUser checkCredentials(String email, String password) {
		// dao.isLoginCredentialsValid(String email, String password);
		if (email != null)
			email = email.toLowerCase();
		return dao.isLoginCredentialsValid(email, password);
	}

	public Map<Object, Object> addNewEvent(NGOEvent event) {
		NGOEvent dbEvent = dao.saveNewEvent(event);

		Map<Object, Object> map = new HashMap<Object, Object>();

		map.put("message", "Event Created Successfully!");
		map.put("event", dbEvent);

		return map;
	}

	public Map<Object, Object> addNewJob(NGOJob job) {
		NGOJob dbJob = dao.saveNewJob(job);

		Map<Object, Object> map = new HashMap<Object, Object>();

		map.put("message", "Job Created Successfully");

		map.put("job", dbJob);

		return map;

	}

	public Map<Object, Object> addNewFundraiser(NGOFundRaiser fundRaiser) {
		NGOFundRaiser dbFundRaiser = dao.saveNewFundraiser(fundRaiser);

		Map<Object, Object> map = new HashMap<Object, Object>();

		map.put("message", "Fundraiser Created Successfully");

		map.put("fund", dbFundRaiser);

		return map;
	}

	public Map<Object, Object> getMyEventResponsesMap(String ngoEmail)
	{
		Map<Object, Object> map=new HashMap<Object, Object>();

		List<NGOEventResponse> list=dao.getMyEventResponsesList(ngoEmail);

		if(list.size()==0)
		{
			map.put("message", "No Events are Posted");
			return map;
		}

		else
		{
			map.put("responses", list);
			return map;
		}
	}

	public Map<Object, Object> getMyJobResponsesMap(String ngoEmail)
	{
		Map<Object, Object> map=new HashMap<Object, Object>();

		List<NGOJobResponse> list=dao.getMyJobResponsesList(ngoEmail);

		if(list.size()==0)
		{
			map.put("message", "No Jobs Are Posted");
			return map;
		}

		else
		{
			map.put("responses", list);
			return map;
		}

	}

	public Map<Object, Object> getMyFundraiserResponsesMap(String ngoEmail)
	{
		Map<Object, Object> map=new HashMap<Object, Object>();

		List<NGOFundraiserResponse> list=dao.getMyFundraiserResponsesList(ngoEmail);

		if(list.size()==0)
		{
			map.put("message", "No Fundraisers Are Posted");
			return map;
		}

		else
		{
			map.put("responses", list);
			return map;
		}

	}
}
