package com.ngoportal;

public class Constants {
    public static final String API_SECRET_KEY = "PHASE2MINIPROJECTGROUP8NGOPORTAL"; //Secret key need to generate token

    public static final long TOKEN_VALIDITY = 24 * 60 * 60 * 1000; // Token validity time (in milliseconds)

}
