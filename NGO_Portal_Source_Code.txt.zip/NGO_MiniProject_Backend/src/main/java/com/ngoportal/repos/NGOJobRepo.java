package com.ngoportal.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ngoportal.models.NGOJob;

public interface NGOJobRepo extends JpaRepository<NGOJob, Integer>{

}
