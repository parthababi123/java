package com.ngoportal.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ngoportal.models.NGOFundRaiser;

@Repository
public interface NGOFundRaiserRepo extends JpaRepository<NGOFundRaiser, Integer>{

}
