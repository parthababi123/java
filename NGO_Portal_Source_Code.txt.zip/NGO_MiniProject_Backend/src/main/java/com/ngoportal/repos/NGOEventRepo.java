package com.ngoportal.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ngoportal.models.NGOEvent;

@Repository
public interface NGOEventRepo extends JpaRepository<NGOEvent, Integer>{

}
