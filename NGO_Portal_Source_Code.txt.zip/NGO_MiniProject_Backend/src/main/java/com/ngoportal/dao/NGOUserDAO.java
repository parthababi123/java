package com.ngoportal.dao;

import com.ngoportal.dao.utils.DAOUtils;
import com.ngoportal.exceptions.EndUserAuthException;
import com.ngoportal.exceptions.NgoUserAuthException;
import com.ngoportal.models.*;
import com.ngoportal.repos.NGOEventRepo;
import com.ngoportal.repos.NGOFundRaiserRepo;
import com.ngoportal.repos.NGOJobRepo;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Repository
public class NGOUserDAO {

	private static final String SQL_SAVE_NGO_USER = "INSERT INTO ngo_user_details (ngoEmail, ngoPassword," +
			"ngoName, ngoURL, ngoRegID, ngoAddressLine1, ngoAddressLine2, ngoZipCode, ngoCity, ngoState, ngoContact) " +
			"VALUES (?,?,?,?,?,?,?,?,?,?,?)";
	private static final String SQL_IS_LOGIN_VALID = "SELECT ngoEmail, ngoPassword, ngoName, ngoURL, ngoRegID," +
			"ngoAddressLine1, ngoAddressLine2, ngoZipCode, ngoCity, ngoState, ngoContact FROM ngo_user_details " +
			"WHERE ngoEmail = ?";
	private static final String SQL_COUNT_BY_EMAIL = "SELECT COUNT(*) FROM ngo_user_details WHERE ngoEmail = ?";

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	NGOEventRepo ngoEventRepo;

	@Autowired
	NGOFundRaiserRepo ngoFundRaiserRepo;

	@Autowired
	NGOJobRepo ngoJobRepo;

	@Autowired
	DAOUtils utils;

	public NGOUser saveNGOUser(String ngoEmail, String ngoPassword, String ngoName, String ngoURL, String ngoRegID,
							   String ngoAddress1, String ngoAddress2, int ngoZipCode, String ngoCity, String ngoState,
							   long ngoContact)
	{
		// Write the code here to insert the values in our database;
		//Add Appropriate Exceptions and HttpStatus as well

		NGOUser ngoUser = new NGOUser(ngoEmail, ngoPassword, ngoName, ngoURL, ngoRegID, ngoAddress1, ngoAddress2, ngoZipCode, ngoCity, ngoState, ngoContact);
		String hashedPassword = BCrypt.hashpw(ngoUser.getNgoPass(), BCrypt.gensalt(10));
		try {
			jdbcTemplate.update(connection -> {
				PreparedStatement ps = connection.prepareStatement(SQL_SAVE_NGO_USER);
				ps.setString(1, ngoUser.getNgoEmail());
				ps.setString(2, hashedPassword);
				ps.setString(3, ngoUser.getNgoName());
				ps.setString(4, ngoUser.getNgoURL());
				ps.setString(5, ngoUser.getNgoRegId());
				ps.setString(6, ngoUser.getNgoAddress1());
				ps.setString(7, ngoUser.getNgoAddress2());
				ps.setInt(8, ngoUser.getNgoZipCode());
				ps.setString(9, ngoUser.getNgoCity());
				ps.setString(10, ngoUser.getNgoState());
				ps.setLong(11, ngoUser.getNgoContact());
				return ps;
			});
			return ngoUser;
		} catch (Exception e) {
			throw new NgoUserAuthException("Invalid details, failed to create account");
		}
	}
	
	public NGOUser isLoginCredentialsValid(String email, String password) throws NgoUserAuthException
	{
		// Write the code here to validate credentials from database;
		//Add Appropriate Exceptions and HttpStatus as well

		try {
			NGOUser ngoUser = jdbcTemplate.queryForObject(SQL_IS_LOGIN_VALID, new Object[]{email}, useRowMapper);
			if(!BCrypt.checkpw(password, ngoUser.getNgoPass()))
				throw new EndUserAuthException("Invalid email/password");
			return ngoUser;
		} catch (EmptyResultDataAccessException e) {
			throw new EndUserAuthException("Invalid email/password");
		}
	}

	public NGOEvent saveNewEvent(NGOEvent event)
	{
		try {
			String date = event.getEventDate();
			String[] arr = date.split("-");

			if (Integer.parseInt(arr[1]) > 12) {
				event.setEventDate(arr[2] + "-" + arr[0] + "-" + arr[1]);        //to parse mm-dd-yyyy format
				return ngoEventRepo.save(event);
			}

			if (arr[0].length() == 4)                                        //to parse yyyy-mm-dd	format
				return ngoEventRepo.save(event);

			event.setEventDate(arr[2] + "-" + arr[1] + "-" + arr[0]);            //to parse dd-mm-yyyy format
			return ngoEventRepo.save(event);
		} catch (Exception e) {
			throw new NgoUserAuthException("Error occurred while creating event");
		}
	}

	public NGOJob saveNewJob(NGOJob job)
	{
		try {
			return ngoJobRepo.save(job);
		} catch (Exception e) {
			throw new NgoUserAuthException(e + "Error occurred for job");
		}

	}

	public NGOFundRaiser saveNewFundraiser(NGOFundRaiser fundRaiser)
	{
		return ngoFundRaiserRepo.save(fundRaiser);
	}

	public Integer getCountByEmail(String userEmail) {
		return jdbcTemplate.queryForObject(SQL_COUNT_BY_EMAIL, new Object[]{userEmail}, Integer.class);
	}

	public List<NGOEventResponse> getMyEventResponsesList(String ngoEmail)
	{
		List<NGOEventResponse> list=new ArrayList<NGOEventResponse>();

		List<NGOEvent> ngoEvents=ngoEventRepo.findAll();

		Iterator<NGOEvent> it=ngoEvents.iterator();

		while(it.hasNext())
		{
			NGOEvent obj=it.next();

			if(obj.getNgoEmail().equalsIgnoreCase(ngoEmail))
			{
				int count=utils.getEventResponsesCount(obj.getEventID());

				NGOEventResponse response=new NGOEventResponse(obj.getEventID(), obj.getEventName(),
						obj.getEventDescription(), obj.getEventDate(), obj.getEventLocCity(),
						obj.getEventLocState(), obj.getNgoEmail(), count);

				list.add(response);
			}
		}
		return list;
	}

	public List<NGOJobResponse> getMyJobResponsesList(String ngoEmail)
	{
		List<NGOJobResponse> list=new ArrayList<NGOJobResponse>();

		List<NGOJob> ngoJobs=ngoJobRepo.findAll();

		Iterator<NGOJob> iterator=ngoJobs.iterator();

		while(iterator.hasNext())
		{
			NGOJob obj=iterator.next();
//			System.out.println(obj.getJobID());
			if(obj.getNgoEmail().equalsIgnoreCase(ngoEmail))
			{
//				System.out.println(obj.getNgoEmail());
				int count=utils.getJobResponsesCount(obj.getJobID());

				NGOJobResponse response=new NGOJobResponse(obj.getJobID(), obj.getJobTitle(),
						obj.getJobPosition(), obj.getJobPrimarySkill(), obj.getJobLocation(),
						obj.getJobCTC(), obj.getNgoEmail(), count);
//				System.out.print(response.getJobID());
				list.add(response);
			}

		}
		return list;
	}

	public List<NGOFundraiserResponse> getMyFundraiserResponsesList(String ngoEmail)
	{
		List<NGOFundraiserResponse> list=new ArrayList<NGOFundraiserResponse>();

		List<NGOFundRaiser> ngoFundraisers=ngoFundRaiserRepo.findAll();

		Iterator<NGOFundRaiser> iterator=ngoFundraisers.iterator();

		while(iterator.hasNext())
		{
			NGOFundRaiser obj=iterator.next();
//			System.out.println(obj.getJobID());
			if(obj.getNgoEmail().equalsIgnoreCase(ngoEmail))
			{
//				System.out.println(obj.getNgoEmail());
				int count=utils.getFundraiserResponsesCount(obj.getFrID());

				NGOFundraiserResponse response=new NGOFundraiserResponse(obj.getFrID(), obj.getFrTitle(),
						obj.getFrDescription(), obj.getNgoEmail(), count);
				System.out.print(obj.getNgoEmail());
				list.add(response);
			}

		}
		return list;
	}

	private RowMapper<NGOUser> useRowMapper = ((rs, rowNum) -> {
		return new NGOUser(rs.getString("ngoEmail"),
				rs.getString("ngoPassword"),
				rs.getString("ngoName"),
				rs.getString("ngoURL"),
				rs.getString("ngoRegID"),
				rs.getString("ngoAddressLine1"),
				rs.getString("ngoAddressLine2"),
				rs.getInt("ngoZipCode"),
				rs.getString("ngoCity"),
				rs.getString("ngoState"),
				rs.getLong("ngoContact"));
	});
}
