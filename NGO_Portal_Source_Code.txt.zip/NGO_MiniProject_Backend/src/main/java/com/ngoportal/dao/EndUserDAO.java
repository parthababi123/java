package com.ngoportal.dao;

import com.ngoportal.dao.utils.DAOUtils;
import com.ngoportal.exceptions.EndUserAlreadyRegisteredException;
import com.ngoportal.exceptions.EndUserAuthException;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.ngoportal.models.EndUser;
import com.ngoportal.models.EndUserResponse;
import com.ngoportal.models.NGOEvent;
import com.ngoportal.models.NGOFundRaiser;
import com.ngoportal.models.NGOJob;

import com.ngoportal.repos.NGOEventRepo;
import com.ngoportal.repos.NGOFundRaiserRepo;
import com.ngoportal.repos.NGOJobRepo;

import net.bytebuddy.asm.Advice.OffsetMapping.ForOrigin.Renderer.ForReturnTypeName;

import javax.security.auth.message.AuthException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

@Repository
public class EndUserDAO {

	private static final String SQL_SAVE_END_USER = "INSERT INTO end_user_details (userEmail, userPassword,"
			+ "userFirstName, userMidName, userLastName, userContact, userDOB) VALUES (?,?,?,?,?,?,?)";
	private static final String SQL_IS_LOGIN_VALID = "SELECT userEmail, userFirstName, userMidName, "
			+ "userLastName, userPassword, userContact, userDOB FROM end_user_details WHERE userEmail = ?";
	private static final String SQL_COUNT_BY_EMAIL = "SELECT COUNT(*) FROM end_user_details WHERE userEmail = ?";

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	NGOEventRepo ngoEventRepo;

	@Autowired
	NGOJobRepo ngoJobRepo;

	@Autowired
	NGOFundRaiserRepo ngoFundRepo;

	@Autowired
	DAOUtils utils;

	public EndUser saveEndUser(String userEmail, String userPassword, String userFirstName, String userMiddleName,
			String userLastName, long userContact, String userDOB) throws ParseException {
		EndUser endUser = new EndUser(userEmail, userPassword, userFirstName, userMiddleName, userLastName, userContact,
				userDOB);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date javaDate = sdf.parse(endUser.getUserDOB());
		java.sql.Date endUserDOB = new java.sql.Date(javaDate.getTime());
//		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
//		java.util.Date javaDate = simpleDateFormat.parse(endUser.getUserDOB());
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//		String userDOBString= sdf.format(javaDate);
//		javaDate = sdf.parse(userDOBString);
//		java.sql.Date endUserDOB = new java.sql.Date(javaDate.getTime());

		String hashedPassword = BCrypt.hashpw(endUser.getUserPass(), BCrypt.gensalt(10));
		try {
			jdbcTemplate.update(connection -> {
				PreparedStatement ps = connection.prepareStatement(SQL_SAVE_END_USER);
				ps.setString(1, endUser.getUserEmail());
				ps.setString(2, hashedPassword);
				ps.setString(3, endUser.getUserFirstName());
				ps.setString(4, endUser.getUserMidName());
				ps.setString(5, endUser.getUserLastName());
				ps.setLong(6, endUser.getUserContact());
				ps.setDate(7, endUserDOB);
				return ps;
			});
			return endUser;
		} catch (Exception e) {
			throw new EndUserAuthException("Invalid details, failed to create account");
		}
	}

	public EndUser isLoginCredentialsValid(String email, String password) throws EndUserAuthException {
		// Write the code here to validate credentials from database;
		// Add Appropriate Exceptions and HttpStatus as well
		try {
			EndUser endUser = jdbcTemplate.queryForObject(SQL_IS_LOGIN_VALID, new Object[] { email }, useRowMapper);
			if (!BCrypt.checkpw(password, endUser.getUserPass()))
				throw new EndUserAuthException("Invalid email/password");
			return endUser;
		} catch (EmptyResultDataAccessException e) {
			throw new EndUserAuthException("Invalid email/password");
		}
	}

	public Integer getCountByEmail(String userEmail) {
		return jdbcTemplate.queryForObject(SQL_COUNT_BY_EMAIL, new Object[] { userEmail }, Integer.class);
	}

	private RowMapper<EndUser> useRowMapper = ((rs, rowNum) -> {
		return new EndUser(rs.getString("userEmail"), rs.getString("userPassword"), rs.getString("userFirstName"),
				rs.getString("userMidName"), rs.getString("userLastName"), rs.getLong("userContact"),
				rs.getString("userDOB"));
	});

	public List<NGOEvent> getEventList() {
		List<NGOEvent> list = ngoEventRepo.findAll();

		List<NGOEvent> returnList = new ArrayList<NGOEvent>();

		Iterator<NGOEvent> iterator = list.iterator();

		while (iterator.hasNext()) {
			NGOEvent obj = iterator.next();
			LocalDate dbDate = LocalDate.parse(obj.getEventDate());
			LocalDate localDate = LocalDate.now();

			int x = dbDate.compareTo(localDate);

			if (x >= 0) {
				returnList.add(obj);
			}

		}
		return returnList;
	}

	public List<NGOJob> getJobList() {
		return ngoJobRepo.findAll();
	}

	public List<NGOFundRaiser> getFundraiserList() {
		return ngoFundRepo.findAll();
	}

	public Boolean saveEventRegistration(int id, String email) {
		if (utils.isEventRegistered(id, email)) {
			throw new EndUserAlreadyRegisteredException("You are already registered");
		}

		String query = "insert into responses_events values (?,?)";
		Boolean result = jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() {
			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);
				ps.setString(2, email);

				if (ps.executeUpdate() > 0)
					return true;
				else
					return false;
			}

		});
		return result;
	}

	public Boolean saveJobRegistration(int id, String email) // Completed At 4:54 PM
	{
		if (utils.isJobApplied(id, email)) {
			throw new EndUserAlreadyRegisteredException("You have applied for the job");
		}
		String query = "insert into responses_jobs values (?,?)";
		Boolean result = jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() {
			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);
				ps.setString(2, email);

				if (ps.executeUpdate() > 0)
					return true;
				else
					return false;
			}

		});
		return result;
	}

	public List<NGOJob> getMyJobsList(String userEmail)
	{
		String query="select res.jobID, jobTitle, jobPosition, jobPrimarySkill, jobLocation, jobCTC, ngoEmail from ngo_job_details ngo inner join responses_jobs res on ngo.jobID=res.jobID and userEmail=?";

		return jdbcTemplate.execute(query, new PreparedStatementCallback<List<NGOJob>>()
		{

			@Override
			public List<NGOJob> doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException
			{
				ps.setString(1, userEmail);

				ResultSet resultSet=ps.executeQuery();

				return utils.buildMyJobsList(resultSet);

			}

		});

	}

	public List<NGOFundRaiser> getMyFundraisersList(String userEmail)
	{
		String query="select res.frID, frTitle, frDescription, ngoEmail from ngo_fundraiser_details ngo inner join responses_fundraisers res on ngo.frID=res.frID and userEmail=?";

		return jdbcTemplate.execute(query, new PreparedStatementCallback<List<NGOFundRaiser>>()
		{

			@Override
			public List<NGOFundRaiser> doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException
			{
				ps.setString(1, userEmail);

				ResultSet resultSet=ps.executeQuery();

				return utils.buildMyFundraisersList(resultSet);

			}

		});

	}

	public List<NGOEvent> getMyEventsList(String userEmail)
	{
		String query="select res.eventID, eventName, eventDescription, eventDate, eventLocCity, eventLocState, ngoEmail from ngo_event_details ngo inner join responses_events res on ngo.eventID=res.eventID and userEmail=? order by eventDate desc";

		return jdbcTemplate.execute(query, new PreparedStatementCallback<List<NGOEvent>>()
		{

			@Override
			public List<NGOEvent> doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException
			{
				ps.setString(1, userEmail);

				ResultSet resultSet=ps.executeQuery();

				return utils.buildMyEventsList(resultSet);

			}

		});

	}
}
