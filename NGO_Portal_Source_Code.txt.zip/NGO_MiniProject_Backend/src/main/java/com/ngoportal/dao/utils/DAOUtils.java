package com.ngoportal.dao.utils;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ngoportal.models.NGOEvent;
import com.ngoportal.models.NGOFundRaiser;
import com.ngoportal.models.NGOJob;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Repository;

@Repository
public class DAOUtils 
{
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	public boolean isEventRegistered(int id, String email)
	{
		String query="select * from responses_events where eventID=? and userEmail=?";
		
		Boolean res=jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() 
		{

			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException 
			{
				ps.setInt(1, id);
				ps.setString(2, email);
				
				ResultSet rs=ps.executeQuery();
				
				if(rs.next())
					return true;
				else
					return false;
			}
			
		});
		if(res)
			return true;
		else
			return false;
	}
	public boolean isJobApplied(int id, String email) 
	{
		String query="select * from responses_jobs where jobID=? and userEmail=?";
		
		Boolean res=jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() 
		{

			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException 
			{
				ps.setInt(1, id);
				ps.setString(2, email);
				
				ResultSet rs=ps.executeQuery();
				
				if(rs.next())
					return true;
				else
					return false;
			}
			
		});
		if(res)
			return true;
		else
			return false;
	}

	public List<NGOJob> buildMyJobsList(ResultSet resultSet) throws SQLException
	{
		int rowCount=0;

		List<NGOJob> list=new ArrayList<NGOJob>();

		while(resultSet.next())
		{
			NGOJob obj=new NGOJob();
			obj.setJobID(resultSet.getInt(1));
			obj.setJobTitle(resultSet.getString(2));
			obj.setJobPosition(resultSet.getString(3));
			obj.setJobPrimarySkill(resultSet.getString(4));
			obj.setJobLocation(resultSet.getString(5));
			obj.setJobCTC(resultSet.getString(6));
			obj.setNgoEmail(resultSet.getString(7));
			list.add(obj);
		}
		return list;
	}

	public List<NGOEvent> buildMyEventsList(ResultSet resultSet) throws SQLException
	{
		int rowCount=0;

		List<NGOEvent> list=new ArrayList<NGOEvent>();

		while(resultSet.next())
		{
			NGOEvent obj=new NGOEvent();
			obj.setEventID(resultSet.getInt(1));
			obj.setEventName(resultSet.getString(2));
			obj.setEventDescription(resultSet.getString(3));
			obj.setEventDate(resultSet.getString(4));
			obj.setEventLocCity(resultSet.getString(5));
			obj.setEventLocState(resultSet.getString(6));
			obj.setNgoEmail(resultSet.getString(7));
			list.add(obj);
		}
		return list;
	}

	public List<NGOFundRaiser> buildMyFundraisersList(ResultSet resultSet) throws SQLException
	{
		int rowCount=0;

		List<NGOFundRaiser> list=new ArrayList<NGOFundRaiser>();

		while(resultSet.next())
		{
			NGOFundRaiser obj=new NGOFundRaiser();
			obj.setFrID(resultSet.getInt(1));
			obj.setFrTitle(resultSet.getString(2));
			obj.setFrDescription(resultSet.getString(3));
			obj.setNgoEmail(resultSet.getString(4));
			list.add(obj);
		}
		return list;
	}

	public int getEventResponsesCount(int eventID)
	{
		String query="select COUNT(*) from responses_events where eventID=?";

		return jdbcTemplate.execute(query, new PreparedStatementCallback<Integer>()
		{
			@Override
			public Integer doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException
			{
				ps.setInt(1, eventID);

				ResultSet resultSet=ps.executeQuery();

				resultSet.next();

				return resultSet.getInt(1);
			}

		});
	}

	public int getJobResponsesCount(int jobID)
	{
		String query="select COUNT(*) from responses_jobs where jobID=?";

		return jdbcTemplate.execute(query, new PreparedStatementCallback<Integer>()
		{
			@Override
			public Integer doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException
			{
				ps.setInt(1, jobID);

				ResultSet resultSet=ps.executeQuery();

				resultSet.next();

				return resultSet.getInt(1);
			}
		});
	}

	public int getFundraiserResponsesCount(int frID)
	{
		String query="select COUNT(*) from responses_fundraisers where frID=?";

		return jdbcTemplate.execute(query, new PreparedStatementCallback<Integer>()
		{
			@Override
			public Integer doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException
			{
				ps.setInt(1, frID);

				ResultSet resultSet=ps.executeQuery();

				resultSet.next();

				return resultSet.getInt(1);
			}
		});
	}
}
