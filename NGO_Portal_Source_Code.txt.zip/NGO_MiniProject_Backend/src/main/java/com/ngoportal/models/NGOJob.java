package com.ngoportal.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ngo_job_details")
public class NGOJob {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int jobID;
	private String jobTitle;
	private String jobPosition;
	private String jobPrimarySkill;
	private String jobLocation;
	private String jobCTC;
	private String ngoEmail;

	public NGOJob()
	{

	}

	public String getJobCTC() {
		return jobCTC;
	}

	public void setJobCTC(String jobCTC) {
		this.jobCTC = jobCTC;
	}

	public int getJobID() {
		return jobID;
	}

	public void setJobID(int jobID) {
		this.jobID = jobID;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getJobPosition() {
		return jobPosition;
	}

	public void setJobPosition(String jobPosition) {
		this.jobPosition = jobPosition;
	}

	public String getJobPrimarySkill() {
		return jobPrimarySkill;
	}

	public void setJobPrimarySkill(String jobPrimarySkill) {
		this.jobPrimarySkill = jobPrimarySkill;
	}

	public String getNgoEmail() {
		return ngoEmail;
	}

	public void setNgoEmail(String ngoEmail) {
		this.ngoEmail = ngoEmail;
	}

	public String getJobLocation() {
		return jobLocation;
	}

	public void setJobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
	}



}
