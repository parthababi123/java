package com.ngoportal.models;

public class NGOUser					
{		
	private String ngoEmail; 									
	private String ngoPass; 		
	private String ngoName; 		
	private String ngoURL;		
	private String ngoRegId;
	private NGOUserAddress address;		
	private long ngoContact;
	
	/*This is POJO for NGOUser
	  Here NGOAddress is an association
	*/

	public NGOUser(String ngoEmail, String ngoPass, String ngoName, String ngoURL, String ngoRegId,
				   String ngoAddress1, String ngoAddress2, int ngoZipCode, String ngoCity, String ngoState, long ngoContact) {
		this.ngoEmail = ngoEmail;
		this.ngoPass = ngoPass;
		this.ngoName = ngoName;
		this.ngoURL = ngoURL;
		this.ngoRegId = ngoRegId;
		this.address = new NGOUserAddress(ngoAddress1, ngoAddress2, ngoZipCode, ngoCity, ngoState);
		this.ngoContact = ngoContact;
	}

	public String getNgoEmail() {
		return ngoEmail;
	}

	public void setNgoEmail(String ngoEmail) {
		this.ngoEmail = ngoEmail;
	}

	public String getNgoPass() {
		return ngoPass;
	}

	public void setNgoPass(String ngoPass) {
		this.ngoPass = ngoPass;
	}

	public String getNgoName() {
		return ngoName;
	}

	public void setNgoName(String ngoName) {
		this.ngoName = ngoName;
	}

	public String getNgoURL() {
		return ngoURL;
	}

	public void setNgoURL(String ngoURL) {
		this.ngoURL = ngoURL;
	}

	public String getNgoRegId() {
		return ngoRegId;
	}

	public void setNgoRegId(String ngoRegId) {
		this.ngoRegId = ngoRegId;
	}

//	public NGOUserAddress getAddress() {
//		return address;
//	}
//
//	public void setAddress(NGOUserAddress address) {
//		this.address = address;
//	}

	public String getNgoAddress1(){
		return this.address.getNgoAddressLine1();
	}

	public void setNgoAddress1(String ngoAddress1){
		this.address.setNgoAddressLine1(ngoAddress1);
	}

	public String getNgoAddress2(){
		return this.address.getNgoAddressLine2();
	}

	public void setNgoAddress2(String ngoAddress2) {
		this.address.setNgoAddressLine2(ngoAddress2);
	}

	public int getNgoZipCode() {
		return this.address.getNgoZipCode();
	}

	public void setNgoZipCode(int ngoZipCode) {
		this.address.setNgoZipCode(ngoZipCode);
	}

	public String getNgoCity() {
		return this.address.getNgoCity();
	}

	public void setNgoCity(String ngoCity) {
		this.address.setNgoCity(ngoCity);
	}

	public String getNgoState() {
		return this.address.getNgoState();
	}

	public void setNgoState(String ngoState) {
		this.address.setNgoState(ngoState);
	}

	public long getNgoContact() {
		return ngoContact;
	}

	public void setNgoContact(long ngoContact) {
		this.ngoContact = ngoContact;
	}
}
