package com.ngoportal.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ngo_event_details")							//Maps to this table
public class NGOEvent {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)		//Auto Incremented values
	private int eventID;
	private String eventName;
	private String eventDescription;
	private String eventDate;									//yyyy-mm-dd
	private String eventLocCity;
	private String eventLocState;
	private String ngoEmail;

	public NGOEvent()
	{

	}

	public int getEventID() {
		return eventID;
	}

	public void setEventID(int eventID) {
		this.eventID = eventID;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getEventLocCity() {
		return eventLocCity;
	}

	public void setEventLocCity(String eventLocCity) {
		this.eventLocCity = eventLocCity;
	}

	public String getEventLocState() {
		return eventLocState;
	}

	public void setEventLocState(String eventLocState) {
		this.eventLocState = eventLocState;
	}

	public String getNgoEmail() {
		return ngoEmail;
	}

	public void setNgoEmail(String ngoEmail) {
		this.ngoEmail = ngoEmail;
	}
}
