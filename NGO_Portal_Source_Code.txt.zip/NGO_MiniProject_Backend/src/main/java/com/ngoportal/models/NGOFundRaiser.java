package com.ngoportal.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ngo_fundraiser_details")
public class NGOFundRaiser {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int frID;
	private String frTitle;
	private String frDescription;
	private String ngoEmail;

	public NGOFundRaiser()
	{

	}

	public int getFrID() {
		return frID;
	}

	public void setFrID(int frID) {
		this.frID = frID;
	}

	public String getFrTitle() {
		return frTitle;
	}

	public void setFrTitle(String frTitle) {
		this.frTitle = frTitle;
	}

	public String getFrDescription() {
		return frDescription;
	}

	public void setFrDescription(String frDescription) {
		this.frDescription = frDescription;
	}

	public String getNgoEmail() {
		return ngoEmail;
	}

	public void setNgoEmail(String ngoEmail) {
		this.ngoEmail = ngoEmail;
	}


}

