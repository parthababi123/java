package com.ngoportal.models;

public class EndUserResponse
{
	private int id;
	private String userEmail;
	
	public EndUserResponse() 
	{
		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	
	
	
}