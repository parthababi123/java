package com.ngoportal.models;

public class NGOEventResponse
{
    private int eventID;
    private String eventName;
    private String eventDescription;
    private String eventDate;									//yyyy-mm-dd
    private String eventLocCity;
    private String eventLocState;
    private String ngoEmail;
    private int responsesCount;

    public NGOEventResponse()
    {

    }

    public NGOEventResponse(int eventID, String eventName, String eventDescription, String eventDate, String eventLocCity, String eventLocState, String ngoEmail, int responsesCount) {

        this.eventID = eventID;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.eventDate = eventDate;
        this.eventLocCity = eventLocCity;
        this.eventLocState = eventLocState;
        this.ngoEmail = ngoEmail;
        this.responsesCount = responsesCount;
    }



    public int getEventID() {
        return eventID;
    }
    public void setEventID(int eventID) {
        this.eventID = eventID;
    }
    public String getEventName() {
        return eventName;
    }
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
    public String getEventDescription() {
        return eventDescription;
    }
    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }
    public String getEventDate() {
        return eventDate;
    }
    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }
    public String getEventLocCity() {
        return eventLocCity;
    }
    public void setEventLocCity(String eventLocCity) {
        this.eventLocCity = eventLocCity;
    }
    public String getEventLocState() {
        return eventLocState;
    }
    public void setEventLocState(String eventLocState) {
        this.eventLocState = eventLocState;
    }
    public String getNgoEmail() {
        return ngoEmail;
    }
    public void setNgoEmail(String ngoEmail) {
        this.ngoEmail = ngoEmail;
    }
    public int getResponsesCount() {
        return responsesCount;
    }
    public void setResponsesCount(int responsesCount) {
        this.responsesCount = responsesCount;
    }
}