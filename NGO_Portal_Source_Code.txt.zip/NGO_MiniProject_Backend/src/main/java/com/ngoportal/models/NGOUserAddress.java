package com.ngoportal.models;

public class NGOUserAddress {

	private String ngoAddressLine1; 	
	private String ngoAddressLine2;	
	private int ngoZipCode;		
	private String ngoCity;		
	private String ngoState;


	public NGOUserAddress(String ngoAddressLine1, String ngoAddressLine2, int ngoZipCode, String ngoCity, String ngoState) {
		this.ngoAddressLine1 = ngoAddressLine1;
		this.ngoAddressLine2 = ngoAddressLine2;
		this.ngoZipCode = ngoZipCode;
		this.ngoCity = ngoCity;
		this.ngoState = ngoState;
	}

	public String getNgoAddressLine1() {
		return ngoAddressLine1;
	}

	public void setNgoAddressLine1(String ngoAddressLine1) {
		this.ngoAddressLine1 = ngoAddressLine1;
	}

	public String getNgoAddressLine2() {
		return ngoAddressLine2;
	}

	public void setNgoAddressLine2(String ngoAddressLine2) {
		this.ngoAddressLine2 = ngoAddressLine2;
	}

	public int getNgoZipCode() {
		return ngoZipCode;
	}

	public void setNgoZipCode(int ngoZipCode) {
		this.ngoZipCode = ngoZipCode;
	}

	public String getNgoCity() {
		return ngoCity;
	}

	public void setNgoCity(String ngoCity) {
		this.ngoCity = ngoCity;
	}

	public String getNgoState() {
		return ngoState;
	}

	public void setNgoState(String ngoState) {
		this.ngoState = ngoState;
	}
}
