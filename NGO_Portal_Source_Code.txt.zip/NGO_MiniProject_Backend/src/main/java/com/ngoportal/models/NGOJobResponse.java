package com.ngoportal.models;

public class NGOJobResponse
{
    private int jobID;
    private String jobTitle;
    private String jobPosition;
    private String jobPrimarySkill;
    private String jobLocation;
    private String jobCTC;
    private String ngoEmail;
    private int responsesCount;

    public NGOJobResponse()
    {

    }

    public NGOJobResponse(int jobID, String jobTitle, String jobPosition, String jobPrimarySkill,
                          String jobLocation,String jobCTC, String ngoEmail, int responsesCount)
    {
        this.jobID = jobID;
        this.jobTitle = jobTitle;
        this.jobPosition = jobPosition;
        this.jobPrimarySkill = jobPrimarySkill;
        this.jobLocation = jobLocation;
        this.jobCTC = jobCTC;
        this.ngoEmail = ngoEmail;
        this.responsesCount = responsesCount;
    }

    public int getJobID() {
        return jobID;
    }

    public void setJobID(int jobID) {
        this.jobID = jobID;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getJobPosition() {
        return jobPosition;
    }

    public void setJobPosition(String jobPosition) {
        this.jobPosition = jobPosition;
    }

    public String getJobPrimarySkill() {
        return jobPrimarySkill;
    }

    public void setJobPrimarySkill(String jobPrimarySkill) {
        this.jobPrimarySkill = jobPrimarySkill;
    }

    public String getJobLocation() {
        return jobLocation;
    }

    public void setJobLocation(String jobLocation) {
        this.jobLocation = jobLocation;
    }

    public String getJobCTC() {
        return jobCTC;
    }

    public void setJobCTC(String jobCTC) {
        this.jobCTC = jobCTC;
    }

    public String getNgoEmail() {
        return ngoEmail;
    }

    public void setNgoEmail(String ngoEmail) {
        this.ngoEmail = ngoEmail;
    }

    public int getResponsesCount() {
        return responsesCount;
    }

    public void setResponsesCount(int responsesCount) {
        this.responsesCount = responsesCount;
    }
}