package com.ngoportal.models;

public class EndUser 
{
	private String userEmail;
	private String userPass;
	private String userFirstName;
	private String userMidName;
	private String userLastName;
	private long userContact;
	private String userDOB;				//Must be in format yyyy-mm-dd will be parsed and then Stored as DB in SQL
	
	/*This is POJO for EndUser
	  Here NGOAdrdress is an association		
	*/

	public EndUser(String userEmail, String userPass, String userFirstName, String userMidName, String userLastName, long userContact, String userDOB) {
		this.userEmail = userEmail;
		this.userPass = userPass;
		this.userFirstName = userFirstName;
		this.userMidName = userMidName;
		this.userLastName = userLastName;
		this.userContact = userContact;
		this.userDOB = userDOB;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserMidName() {
		return userMidName;
	}

	public void setUserMidName(String userMidName) {
		this.userMidName = userMidName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public long getUserContact() {
		return userContact;
	}

	public void setUserContact(long userContact) {
		this.userContact = userContact;
	}

	public String getUserDOB() {
		return userDOB;
	}

	public void setUserDOB(String userDOB) {
		this.userDOB = userDOB;
	}
}
