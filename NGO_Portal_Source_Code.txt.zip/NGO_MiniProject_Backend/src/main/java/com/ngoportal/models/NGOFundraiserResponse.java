package com.ngoportal.models;

public class NGOFundraiserResponse {
    private int frID;
    private String frTitle;
    private String frDescription;
    private String ngoEmail;
    private int responsesCount;

    public NGOFundraiserResponse () {}

    public NGOFundraiserResponse(int frID, String frTitle, String frDescription, String ngoEmail, int responsesCount) {
        this.frID = frID;
        this.frTitle = frTitle;
        this.frDescription = frDescription;
        this.ngoEmail = ngoEmail;
        this.responsesCount = responsesCount;
    }

    public int getFrID() {
        return frID;
    }

    public void setFrID(int frID) {
        this.frID = frID;
    }

    public String getFrTitle() {
        return frTitle;
    }

    public void setFrTitle(String frTitle) {
        this.frTitle = frTitle;
    }

    public String getFrDescription() {
        return frDescription;
    }

    public void setFrDescription(String frDescription) {
        this.frDescription = frDescription;
    }

    public String getNgoEmail() {
        return ngoEmail;
    }

    public void setNgoEmail(String ngoEmail) {
        this.ngoEmail = ngoEmail;
    }

    public int getResponsesCount() {
        return responsesCount;
    }

    public void setResponsesCount(int responsesCount) {
        this.responsesCount = responsesCount;
    }
}
