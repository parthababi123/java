package com.ngoportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgoPortalGrp8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
